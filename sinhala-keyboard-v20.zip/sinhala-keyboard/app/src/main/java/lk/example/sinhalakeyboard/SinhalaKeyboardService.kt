package lk.example.sinhalakeyboard

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SinhalaKeyboardService : InputMethodService() {

    private enum class Panel { LETTERS, NUMBERS, NUMBERS2, EMOJI, SYMBOLS, CLIP, STYLE }

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var kbTheme: KbTheme = Themes.all[0]
    private var wallpaper = 0
    private var panel = Panel.LETTERS
    private var sinhalaMode = true
    private var shift = false
    private var capsLock = false
    private var lastShiftTap = 0L

    private var fast = true
    private var vibrate = true
    private var sound = false
    private var repeatMs = 55L
    private var keyHeightDp = 48
    private var numberRow = false
    private var suggestOn = true
    private var learnOn = true
    private var doubleSpace = true
    private var autoCap = true
    private var smart = true
    private var flatKeys = true
    private var ultra = true
    private var repeatDelay = 380L
    private val sugRunnable = Runnable { suggestNow() }
    private var rgbMode = 0

    private val rgbDrawables = ArrayList<RgbKeyDrawable>()
    private var rgbRunning = false
    private val rgbTick = object : Runnable {
        override fun run() {
            if (!rgbRunning) return
            for (d in rgbDrawables) d.invalidateSelf()
            handler.postDelayed(this, 45)
        }
    }
    private var clipboard: android.content.ClipboardManager? = null
    private val clipListener = android.content.ClipboardManager.OnPrimaryClipChangedListener { grabClip() }

    private val buffer = StringBuilder()
    private val letterKeys = ArrayList<Pair<TextView, Char>>()
    private var shiftKey: TextView? = null
    private var suggestionRow: LinearLayout? = null
    private var wallView: LiveWallpaperView? = null
    private var lastSug = 0L
    private var lastPreviewAt = 0L
    private var inputRoot: View? = null

    private val learnedCache = HashMap<String, Int>()
    private val dict = HashMap<String, String>() // spelling without ZWJ -> word
    private var builtinWords: List<String> = emptyList()
    private var dirty = true
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> dirty = true }

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.of(this)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        builtinWords = try {
            assets.open("words.txt").bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() }
        } catch (e: Exception) {
            emptyList()
        }
        reloadLearned()
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
        clipboard?.addPrimaryClipChangedListener(clipListener)
        Thread {
            loadEnglish()
            GlyphData.load(applicationContext, "emoji.txt")
            GlyphData.load(applicationContext, "symbols.txt")
        }.start()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        clipboard?.removePrimaryClipChangedListener(clipListener)
        try { previewWin?.dismiss() } catch (e: Exception) { }
        stopRgb()
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        loadSettings()
        dirty = false
        return buildView()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) {
            reloadLearned()
            buffer.clear()
            shift = false
            capsLock = false
            val needRebuild = dirty || panel != Panel.LETTERS
            panel = Panel.LETTERS
            if (needRebuild) {
                dirty = false
                loadSettings()
                setInputView(buildView())
            } else {
                updateSuggestions()
                updateShiftUi()
            }
        }
        autoCapFromContext()
        grabClip()
        startRgb()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        commitComposing()
        stopRgb()
        super.onFinishInputView(finishingInput)
    }

    // ---------- English word suggestions ----------

    @Volatile private var enWords: Array<String> = emptyArray()
    @Volatile private var enOrder: IntArray = IntArray(0)
    private val enLearned = HashMap<String, Int>()
    private var stripToolbar = true
    private val enRunnable = Runnable { enSuggest() }
    private val enAlias = mapOf(
        "im" to "I'm", "dont" to "don't", "cant" to "can't", "ive" to "I've", "youre" to "you're",
        "thats" to "that's", "whats" to "what's", "didnt" to "didn't", "doesnt" to "doesn't", "isnt" to "isn't",
        "wont" to "won't", "wouldnt" to "wouldn't", "couldnt" to "couldn't", "shouldnt" to "shouldn't",
        "lets" to "let's", "arent" to "aren't", "wasnt" to "wasn't", "havent" to "haven't", "theyre" to "they're",
        "i" to "I"
    )

    private fun loadEnglish() {
        try {
            val arr = assets.open("en_words.txt").bufferedReader().readLines().filter { it.isNotEmpty() }.toTypedArray()
            val idx = (0 until arr.size).sortedBy { arr[it] }.toIntArray()
            enOrder = idx
            enWords = arr
        } catch (e: Exception) {
            // no English suggestions then
        }
        try {
            val raw = Prefs.of(this).getString("en_learned", "") ?: ""
            for (part in raw.split(",")) {
                val i = part.lastIndexOf(':')
                if (i > 0) enLearned[part.substring(0, i)] = part.substring(i + 1).toIntOrNull() ?: 1
            }
        } catch (e: Exception) {
        }
    }

    /** The English word right before the cursor (letters and apostrophes). */
    private fun currentEnWord(): String {
        val before = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString() ?: return ""
        var i = before.length
        while (i > 0) {
            val ch = before[i - 1]
            if ((ch in 'a'..'z') || (ch in 'A'..'Z') || ch == '\'') i-- else break
        }
        return before.substring(i)
    }

    private fun enComplete(prefix: String, limit: Int): List<String> {
        val words = enWords
        val order = enOrder
        val out = ArrayList<String>()
        // words the user typed before come first
        val mine = enLearned.entries.filter { it.key.length > prefix.length && it.key.startsWith(prefix) }
            .sortedByDescending { it.value }.take(2)
        for (m in mine) out.add(m.key)
        if (order.isEmpty()) return out
        var lo = 0
        var hi = order.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (words[order[mid]] < prefix) lo = mid + 1 else hi = mid
        }
        val best = ArrayList<Int>()
        var i = lo
        while (i < order.size) {
            val r = order[i]
            val w = words[r]
            if (!w.startsWith(prefix)) break
            if (w.length > prefix.length && (best.size < limit || r < best[best.size - 1])) {
                best.add(r)
                best.sort()
                if (best.size > limit) best.removeAt(limit)
            }
            i++
        }
        for (r in best) if (words[r] !in out) out.add(words[r])
        return out
    }

    private fun isEnWord(w: String): Boolean {
        val words = enWords
        val order = enOrder
        var lo = 0
        var hi = order.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (words[order[mid]] < w) lo = mid + 1 else hi = mid
        }
        return lo < order.size && words[order[lo]] == w
    }

    private fun scheduleEnSuggest() {
        if (sinhalaMode && buffer.isNotEmpty()) return
        handler.removeCallbacks(enRunnable)
        handler.postDelayed(enRunnable, 25L)
    }

    private fun matchCase(typed: String, w: String): String = when {
        typed.length > 1 && typed.all { it.isUpperCase() || it == '\'' } -> w.uppercase()
        typed.isNotEmpty() && typed[0].isUpperCase() -> w.replaceFirstChar { it.uppercaseChar() }
        else -> w
    }

    private fun enSuggest() {
        if (sinhalaMode && buffer.isNotEmpty()) return
        val row = suggestionRow ?: return
        val typed = currentEnWord()
        if (typed.isEmpty() || styleFont >= 0 || panel != Panel.LETTERS) {
            if (!stripToolbar) updateSuggestions()
            return
        }
        val low = typed.lowercase()
        val items = LinkedHashSet<String>()
        val alias = enAlias[low]
        if (alias != null && alias != typed) items.add(alias)
        items.add(typed)
        for (w in enComplete(low, 4)) items.add(matchCase(typed, w))
        row.removeAllViews()
        stripToolbar = false
        var first = true
        for (w in items.take(5)) {
            val chipText = w
            val c = chip(chipText, 18f) { pickEnglish(chipText) }
            if (first && flatKeys) c.setTypeface(c.typeface, android.graphics.Typeface.BOLD)
            first = false
            row.addView(c)
        }
    }

    private fun pickEnglish(word: String) {
        val ic = currentInputConnection ?: return
        val typed = currentEnWord()
        if (typed.isNotEmpty()) ic.deleteSurroundingText(typed.length, 0)
        ic.commitText(word + " ", 1)
        learnEnglish(word)
        autoCapFromContext()
        scheduleEnSuggest()
    }

    private fun learnEnglish(w: String) {
        if (!learnOn || w.length < 3 || enWords.isEmpty()) return
        val low = w.lowercase()
        if (low.any { it !in 'a'..'z' && it != '\'' }) return
        if (isEnWord(low) && !enLearned.containsKey(low)) return
        if (enLearned.size > 600 && !enLearned.containsKey(low)) return
        enLearned[low] = (enLearned[low] ?: 0) + 1
        Prefs.of(this).edit().putString("en_learned", enLearned.entries.joinToString(",") { it.key + ":" + it.value }).apply()
    }

    private fun reloadLearned() {
        learnedCache.clear()
        for ((k, v) in Prefs.learned(this).all) {
            if (v is Int) learnedCache[k] = v
        }
        buildDictionary()
    }

    private fun norm(s: String): String = s.replace("\u200D", "")

    /** Built-in words plus words you have used at least twice. */
    private fun buildDictionary() {
        dict.clear()
        for (w in builtinWords) dict[norm(w)] = w
        for ((w, n) in learnedCache) {
            val key = norm(w)
            if (n >= 2 && !dict.containsKey(key)) dict[key] = w
        }
    }

    /** What the typed letters should become: the plain conversion, or a known word if one fits. */
    private fun bestForm(guesses: List<String>): String {
        val primary = guesses[0]
        if (!smart) return primary
        val own = dict[norm(primary)]
        if (own != null) return own
        for (i in 1 until guesses.size) {
            val hit = dict[norm(guesses[i])]
            if (hit != null) return hit
        }
        return primary
    }

    private fun loadSettings() {
        kbTheme = Themes.all[prefs.getInt(Prefs.THEME, 0).coerceIn(0, Themes.all.size - 1)]
        wallpaper = prefs.getInt(Prefs.WALLPAPER, 0).coerceIn(0, Wallpapers.names.size - 1)
        fast = prefs.getBoolean(Prefs.FAST, true)
        vibrate = prefs.getBoolean(Prefs.VIBRATE, true)
        sound = prefs.getBoolean(Prefs.SOUND, false)
        repeatMs = when (prefs.getInt(Prefs.REPEAT, 1)) {
            0 -> 90L
            2 -> 32L
            else -> 55L
        }
        keyHeightDp = when (prefs.getInt(Prefs.HEIGHT, 1)) {
            0 -> 42
            2 -> 56
            else -> 48
        }
        numberRow = prefs.getBoolean(Prefs.NUMBER_ROW, false)
        suggestOn = prefs.getBoolean(Prefs.SUGGEST, true)
        learnOn = prefs.getBoolean(Prefs.LEARN, true)
        doubleSpace = prefs.getBoolean(Prefs.DOUBLE_SPACE, true)
        autoCap = prefs.getBoolean(Prefs.AUTO_CAP, true)
        smart = prefs.getBoolean(Prefs.SMART, true)
        ultra = prefs.getBoolean(Prefs.ULTRA, true)
        keyPreview = prefs.getBoolean(Prefs.PREVIEW, true)
        flatKeys = prefs.getBoolean(Prefs.FLAT, true)
        styleFont = prefs.getInt(Prefs.STYLE_FONT, -1)
        styleDeco = prefs.getInt(Prefs.STYLE_DECO, -1)
        if (ultra) {
            repeatMs = 24L
            repeatDelay = 260L
        } else {
            repeatDelay = 380L
        }
        rgbMode = prefs.getInt(Prefs.RGB, 0).coerceIn(0, 3)
        sinhalaMode = prefs.getBoolean(Prefs.SINHALA, true)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun refresh() = setInputView(buildView())
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- views ----------

    private fun buildView(): View {
        letterKeys.clear()
        rgbDrawables.clear()
        shiftKey = null
        val frame = KeyboardFrame(this)
        val bg = LiveWallpaperView(this)
        wallView = bg
        bg.configure(wallpaper, kbTheme)
        frame.addView(
            bg,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(6))
        }
        content.addView(suggestionStrip())
        when (panel) {
            Panel.LETTERS -> letterRows(content)
            Panel.NUMBERS -> numberRows(content, false)
            Panel.NUMBERS2 -> numberRows(content, true)
            Panel.EMOJI -> glyphPanel(content, "emoji.txt", "emoji")
            Panel.SYMBOLS -> glyphPanel(content, "symbols.txt", "symbols")
            Panel.CLIP -> clipPanel(content)
            Panel.STYLE -> stylePanel(content)
        }
        frame.addView(
            content,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        if ((rgbMode and 1) != 0) {
            frame.addView(
                RgbBorderView(this),
                FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            )
        }
        inputRoot = frame
        updateSuggestions()
        startRgb()
        return frame
    }

    private fun suggestionStrip(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        suggestionRow = row
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            if (flatKeys) setBackgroundColor(0x33000000)
            addView(row)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        }
    }

    private fun chip(text: String, size: Float, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        setTextColor(if (flatKeys) kbTheme.text else kbTheme.accent)
        textSize = size
        gravity = Gravity.CENTER
        minWidth = if (flatKeys) dp(84) else 0
        setPadding(dp(14), 0, dp(14), 0)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )
        setOnClickListener { onClick() }
    }

    private fun tbIcon(kind: Ic, label: String = "", active: Boolean = false, onClick: () -> Unit): View {
        val v = IconView(
            this, kind, label,
            circle = true,
            iconColor = if (active) kbTheme.accent else kbTheme.text,
            circleColor = Themes.alpha(kbTheme.text, if (active) 0x40 else 0x26)
        )
        val lp = LinearLayout.LayoutParams(dp(38), dp(38))
        lp.setMargins(dp(5), dp(3), dp(5), dp(3))
        v.layoutParams = lp
        v.setOnClickListener { onClick() }
        return v
    }

    private fun updateSuggestions() {
        val row = suggestionRow ?: return
        if (sinhalaMode && buffer.isNotEmpty()) {
            val raw = buffer.toString()
            val guesses = Transliterator.guesses(raw)
            fillSuggestions(raw, guesses, bestForm(guesses))
            return
        }
        row.removeAllViews()
        stripToolbar = true
        row.addView(tbIcon(Ic.LANG, if (sinhalaMode) "සි" else "En") { toggleLanguage() })
        row.addView(tbIcon(Ic.EMOJI) { switchPanel(Panel.EMOJI) })
        row.addView(tbIcon(Ic.SPARKLE) { switchPanel(Panel.SYMBOLS) })
        row.addView(tbIcon(Ic.FONT, active = styleFont >= 0 || styleDeco >= 0 || panel == Panel.STYLE) { switchPanel(Panel.STYLE) })
        row.addView(tbIcon(Ic.CLIP, active = panel == Panel.CLIP) { switchPanel(Panel.CLIP) })
        row.addView(tbIcon(Ic.DOWNLOAD) { openStatusSaver() })
        row.addView(tbIcon(Ic.GLOBE) { openBrowser() })
        row.addView(tbIcon(Ic.RGB) { cycleRgb() })
        row.addView(tbIcon(Ic.THEME) { cycleTheme() })
        row.addView(tbIcon(Ic.WALL) { cycleWallpaper() })
        row.addView(tbIcon(Ic.BOLT, active = fast || ultra) { toggleFast() })
        row.addView(tbIcon(Ic.GEAR) { openApp() })
        row.addView(tbIcon(Ic.CHEVRON) { requestHideSelf(0) })
    }

    private fun fillSuggestions(raw: String, guesses: List<String>, shown: String) {
        val row = suggestionRow ?: return
        row.removeAllViews()
        stripToolbar = false
        val items = LinkedHashSet<String>()
        items.add(shown)
        items.add(guesses[0])
        if (suggestOn) {
            for (g in guesses) {
                val hit = dict[norm(g)]
                if (hit != null) items.add(hit)
            }
            items.addAll(matches(guesses.take(4), items))
            for (v in guesses.drop(1).take(2)) items.add(v)
        }
        items.add(raw)
        for (w in items) row.addView(chip(w, 18f) { pick(w) })
    }

    /** Re-reads the typed letters, shows the Sinhala text in the field and refreshes the suggestion bar. */
    private fun refreshComposing() {
        val raw = buffer.toString()
        if (ultra) {
            // ultra fast typing: show the plain conversion at once, work out suggestions when typing pauses
            val quick = Transliterator.convert(raw)
            currentInputConnection?.setComposingText(quick, 1)
            quickStrip(raw, quick)
            handler.removeCallbacks(sugRunnable)
            // full suggestions: right after a short pause, and at least every ~200 ms while typing continuously
            handler.postDelayed(sugRunnable, if (SystemClock.uptimeMillis() - lastSug > 200L) 0L else 55L)
            return
        }
        val guesses = Transliterator.guesses(raw)
        val shown = bestForm(guesses)
        currentInputConnection?.setComposingText(shown, 1)
        fillSuggestions(raw, guesses, shown)
    }

    /** Instant two-chip strip while typing fast; the full list follows a moment later. */
    private fun quickStrip(raw: String, shown: String) {
        val row = suggestionRow ?: return
        row.removeAllViews()
        stripToolbar = false
        row.addView(chip(shown, 18f) { pick(shown) })
        if (raw != shown) row.addView(chip(raw, 18f) { pick(raw) })
    }

    private fun suggestNow() {
        lastSug = SystemClock.uptimeMillis()
        if (buffer.isEmpty() || !sinhalaMode) return
        val raw = buffer.toString()
        val guesses = Transliterator.guesses(raw)
        val shown = bestForm(guesses)
        currentInputConnection?.setComposingText(shown, 1)
        fillSuggestions(raw, guesses, shown)
    }

    private fun matches(prefixes: List<String>, exclude: Collection<String>): List<String> {
        val keys = prefixes.map { norm(it).removeSuffix("්") }.filter { it.isNotEmpty() }.distinct()
        if (keys.isEmpty()) return emptyList()
        val found = LinkedHashMap<String, Int>()
        for ((k, form) in dict) {
            if (form !in exclude && keys.any { k.startsWith(it) }) found[form] = learnedCache[form] ?: 0
        }
        for ((form, n) in learnedCache) {
            if (form !in exclude && keys.any { norm(form).startsWith(it) }) found[form] = n
        }
        return found.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key.length })
            .take(6)
            .map { it.key }
    }

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(keyHeightDp))
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
    }

    /** Gboard style: no key boxes, a soft pill for the space bar and a round accent enter key. */
    private fun flatBackground(shape: Int): StateListDrawable {
        val pressed = GradientDrawable().apply {
            cornerRadius = dp(if (shape == 0) 12 else 28).toFloat()
            setColor(Themes.alpha(kbTheme.accent, 0x66))
        }
        val normal = GradientDrawable().apply {
            when (shape) {
                1 -> { cornerRadius = dp(16).toFloat(); setColor(Themes.alpha(kbTheme.key, 0xE0)) }
                2 -> { cornerRadius = dp(30).toFloat(); setColor(kbTheme.accent) }
                else -> setColor(0)
            }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    private fun onAccent(): Int {
        val a = kbTheme.accent
        val lum = 0.299 * ((a shr 16) and 0xFF) + 0.587 * ((a shr 8) and 0xFF) + 0.114 * (a and 0xFF)
        return if (lum > 150) 0xFF1B1B1F.toInt() else 0xFFFFFFFF.toInt()
    }

    private fun spaceLabel(): String = if (sinhalaMode) "සිංහල" else "English"

    private fun keyBackground(special: Boolean): StateListDrawable {
        val alphaN = if (wallpaper != 0) 0xC8 else 0xFF
        val normal = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Themes.alpha(if (special) kbTheme.special else kbTheme.key, alphaN))
        }
        val pressed = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Themes.alpha(kbTheme.accent, 0xB0))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    private fun rgbBackground(v: View, special: Boolean): RgbKeyDrawable {
        val alphaN = if (wallpaper != 0) 0xC8 else 0xFF
        val d = RgbKeyDrawable(
            v,
            Themes.alpha(if (special) kbTheme.special else kbTheme.key, alphaN),
            Themes.alpha(kbTheme.accent, 0xB0),
            dp(8).toFloat(),
            dp(2).toFloat() * 0.8f,
            Rgb.speed(this)
        )
        rgbDrawables.add(d)
        return d
    }

    private fun key(
        text: String,
        weight: Float,
        special: Boolean = false,
        repeat: Boolean = false,
        pop: Boolean = false,
        shape: Int = 0,
        action: () -> Unit
    ): TextView {
        val tv = TextView(this)
        val flat = flatKeys && (rgbMode and 2) == 0
        tv.text = text
        tv.setTextColor(
            when {
                flat && shape == 2 -> onAccent()
                flat && shape == 1 -> Themes.alpha(kbTheme.text, 0xC0)
                else -> kbTheme.text
            }
        )
        tv.textSize = when {
            flat && shape == 1 -> 15f
            flat && text.contains('\n') -> 13f
            flat -> if (text.length > 2) 15f else 23f
            else -> if (text.length > 2) 14f else 19f
        }
        tv.gravity = Gravity.CENTER
        tv.background = when {
            (rgbMode and 2) != 0 -> rgbBackground(tv, special)
            flat -> flatBackground(shape)
            else -> keyBackground(special)
        }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        if (flat) {
            if (shape == 0) lp.setMargins(0, dp(1), 0, dp(1)) else lp.setMargins(dp(4), dp(5), dp(4), dp(5))
        } else {
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        tv.layoutParams = lp
        attachTouch(tv, repeat, pop, action)
        return tv
    }

    private fun attachTouch(v: View, repeat: Boolean, action: () -> Unit) = attachTouch(v, repeat, false, action)

    private fun attachTouch(v: View, repeat: Boolean, pop: Boolean, action: () -> Unit) {
        var repeater: Runnable? = null
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    wallView?.typing()
                    if (fast || ultra || repeat) {
                        action()
                        feedback(view)
                    }
                    if (pop && view is TextView) {
                        val txt = view.text
                        val t0 = SystemClock.uptimeMillis()
                        if (t0 - lastPreviewAt > 90L) handler.post { showPreview(view, txt) }
                        lastPreviewAt = t0
                    }
                    if (repeat) {
                        val r = object : Runnable {
                            override fun run() {
                                action()
                                feedback(view)
                                handler.postDelayed(this, repeatMs)
                            }
                        }
                        repeater = r
                        handler.postDelayed(r, repeatDelay)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    if (pop) hidePreview()
                    repeater?.let { handler.removeCallbacks(it) }
                    repeater = null
                    if (!fast && !ultra && !repeat) {
                        val inside = ev.x >= 0f && ev.x <= view.width && ev.y >= 0f && ev.y <= view.height
                        if (inside) {
                            feedback(view)
                            action()
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    if (pop) hidePreview()
                    repeater?.let { handler.removeCallbacks(it) }
                    repeater = null
                }
            }
            true
        }
    }

    private var previewWin: android.widget.PopupWindow? = null
    private var previewTv: TextView? = null
    private var keyPreview = true
    private val hidePreviewRunnable = Runnable { try { previewWin?.dismiss() } catch (e: Exception) { } }

    /** Big bubble above the pressed key, like premium keyboards. */
    private fun showPreview(v: View, text: CharSequence) {
        if (!keyPreview) return
        try {
            handler.removeCallbacks(hidePreviewRunnable)
            val pw = previewWin ?: run {
                val tv = TextView(this)
                tv.gravity = Gravity.CENTER
                tv.textSize = 30f
                tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
                val w = android.widget.PopupWindow(tv, dp(56), dp(66))
                w.isTouchable = false
                w.isFocusable = false
                w.isClippingEnabled = false
                previewWin = w
                previewTv = tv
                w
            }
            val tv = previewTv ?: return
            tv.setTextColor(kbTheme.text)
            tv.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Themes.alpha(kbTheme.key, 0xFF))
                setStroke(dp(2), kbTheme.accent)
            }
            tv.text = text
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            val x = loc[0] + v.width / 2 - dp(28)
            val y = loc[1] - dp(66) - dp(2)
            if (pw.isShowing) pw.update(x, y, dp(56), dp(66)) else pw.showAtLocation(v, Gravity.NO_GRAVITY, x, y)
        } catch (e: Exception) {
            // never let the preview break typing
        }
    }

    private fun hidePreview() {
        handler.removeCallbacks(hidePreviewRunnable)
        handler.postDelayed(hidePreviewRunnable, 70L)
    }

    @Suppress("DEPRECATION")
    private fun feedback(v: View?) {
        if (vibrate) {
            v?.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
        if (sound && !ultra) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
    }

    private fun letterLabel(ch: Char): String = if (shift || capsLock) ch.uppercaseChar().toString() else ch.toString()
    private fun shiftLabel(): String = if (capsLock) "⇪" else if (shift) "⬆" else "⇧"

    private fun letterRows(root: LinearLayout) {
        if (numberRow) {
            val row = newRow()
            for (ch in "1234567890") row.addView(key(ch.toString(), 1f, pop = true) { onSymbol(ch.toString()) })
            root.addView(row)
        }
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        for ((idx, r) in rows.withIndex()) {
            val row = newRow()
            if (idx == 1) row.addView(spacer(0.5f))
            if (idx == 2) {
                val sk = key(shiftLabel(), 1.5f, special = true) { onShift() }
                shiftKey = sk
                row.addView(sk)
            }
            for (ch in r) {
                val k = key(letterLabel(ch), 1f, pop = true) { onLetter(ch) }
                letterKeys.add(Pair(k, ch))
                row.addView(k)
            }
            if (idx == 2) row.addView(key("⌫", 1.5f, special = true, repeat = true) { onBackspace() })
            if (idx == 1) row.addView(spacer(0.5f))
            root.addView(row)
        }
        val bottom = newRow()
        if (flatKeys && (rgbMode and 2) == 0) {
            bottom.addView(key("☺\n?123", 1.3f, special = true) { switchPanel(Panel.NUMBERS) })
            bottom.addView(key("🌐", 1.1f, special = true) { toggleLanguage() })
            bottom.addView(key(",", 0.8f) { onSymbol(",") })
            bottom.addView(key(spaceLabel(), 4f, shape = 1) { onSpace() })
            bottom.addView(key(".", 0.8f) { onSymbol(".") })
            bottom.addView(key("↵", 1.3f, special = true, shape = 2) { onEnter() })
        } else {
            bottom.addView(key("?123", 1.3f, special = true) { switchPanel(Panel.NUMBERS) })
            bottom.addView(key("😀", 1.1f, special = true) { switchPanel(Panel.EMOJI) })
            bottom.addView(key(if (sinhalaMode) "SI" else "EN", 1.1f, special = true) { toggleLanguage() })
            bottom.addView(key(",", 0.9f) { onSymbol(",") })
            bottom.addView(key("space", 3f) { onSpace() })
            bottom.addView(key(".", 0.9f) { onSymbol(".") })
            bottom.addView(key("↵", 1.4f, special = true) { onEnter() })
        }
        root.addView(bottom)
    }

    private fun numberRows(root: LinearLayout, second: Boolean) {
        val rows = if (!second) {
            listOf("1234567890", "@#\$%&-+()/", "!?:;\"'*=_")
        } else {
            listOf("~`|•√π÷×¶∆", "£¢€¥^°={}\\", "©®™✓[]<>%")
        }
        for ((idx, r) in rows.withIndex()) {
            val row = newRow()
            for (ch in r) row.addView(key(ch.toString(), 1f, pop = true) { onSymbol(ch.toString()) })
            if (idx == 2) row.addView(key("⌫", 1.5f, special = true, repeat = true) { onBackspace() })
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("ABC", 1.6f, special = true) { switchPanel(Panel.LETTERS) })
        bottom.addView(key(if (second) "1/2" else "2/2", 1.2f, special = true) {
            switchPanel(if (second) Panel.NUMBERS else Panel.NUMBERS2)
        })
        bottom.addView(key(",", 1f) { onSymbol(",") })
        if (flatKeys && (rgbMode and 2) == 0) bottom.addView(key(spaceLabel(), 3.5f, shape = 1) { onSpace() })
        else bottom.addView(key("space", 3.5f) { onSpace() })
        bottom.addView(key(".", 1f) { onSymbol(".") })
        if (flatKeys && (rgbMode and 2) == 0) bottom.addView(key("↵", 1.4f, special = true, shape = 2) { onEnter() })
        else bottom.addView(key("↵", 1.6f, special = true) { onEnter() })
        root.addView(bottom)
    }

    private fun glyphPanel(root: LinearLayout, file: String, kind: String) {
        val cats = GlyphData.withRecents(applicationContext, kind, file)
        val gridH = dp(keyHeightDp) * 3
        root.addView(GlyphPanel.build(this, cats, kbTheme, gridH) { g -> onGlyph(g, kind) })
        val bottom = newRow()
        bottom.addView(key("ABC", 2f, special = true) { switchPanel(Panel.LETTERS) })
        if (kind == "emoji") {
            bottom.addView(key("✨", 1.5f, special = true) { switchPanel(Panel.SYMBOLS) })
        } else {
            bottom.addView(key("😀", 1.5f, special = true) { switchPanel(Panel.EMOJI) })
        }
        bottom.addView(key("space", 4f) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(key("⌫", 2f, special = true, repeat = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(bottom)
    }

    private fun updateShiftUi() {
        for ((tv, ch) in letterKeys) tv.text = letterLabel(ch)
        shiftKey?.text = shiftLabel()
    }

    // ---------- actions ----------

    private fun switchPanel(p: Panel) {
        commitComposing()
        panel = p
        refresh()
    }

    private fun toggleLanguage() {
        commitComposing()
        sinhalaMode = !sinhalaMode
        prefs.edit().putBoolean(Prefs.SINHALA, sinhalaMode).apply()
        refresh()
        autoCapFromContext()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun cycleTheme() {
        val i = (Themes.all.indexOf(kbTheme) + 1) % Themes.all.size
        prefs.edit().putInt(Prefs.THEME, i).apply()
        kbTheme = Themes.all[i]
        toast(kbTheme.name)
        refresh()
    }

    private fun cycleWallpaper() {
        wallpaper = (wallpaper + 1) % Wallpapers.names.size
        prefs.edit().putInt(Prefs.WALLPAPER, wallpaper).apply()
        toast(Wallpapers.names[wallpaper])
        refresh()
    }

    private fun openBrowser() {
        val i = Intent(this, BrowserActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun openStatusSaver() {
        val i = Intent(this, StatusActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun cycleRgb() {
        rgbMode = (rgbMode + 1) % Rgb.modes.size
        prefs.edit().putInt(Prefs.RGB, rgbMode).apply()
        toast("RGB: " + Rgb.modes[rgbMode])
        refresh()
    }

    private fun startRgb() {
        if ((rgbMode and 2) != 0) {
            if (!rgbRunning) {
                rgbRunning = true
                handler.post(rgbTick)
            }
        } else {
            stopRgb()
        }
    }

    private fun stopRgb() {
        rgbRunning = false
        handler.removeCallbacks(rgbTick)
    }

    private fun grabClip() {
        try {
            val clip = clipboard?.primaryClip ?: return
            if (clip.itemCount == 0 || !clip.description.hasMimeType("text/*")) return
            val txt = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
            ClipStore.add(this, txt)
        } catch (e: Exception) {
            // clipboard not readable right now
        }
    }

    private fun clipPanel(root: LinearLayout) {
        val gridH = dp(keyHeightDp) * 3
        val scroll = android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, gridH)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val items = ClipStore.list(this)
        if (items.isEmpty()) {
            col.addView(TextView(this).apply {
                text = "Copy some text and it appears here.\nTap the pin to keep it at the top."
                setTextColor(Themes.alpha(kbTheme.text, 0xB0))
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, dp(30), 0, 0)
            })
        }
        for (item in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor(Themes.alpha(kbTheme.key, 0xDD))
                    if (item.pinned) setStroke(dp(1), kbTheme.accent)
                }
                setPadding(dp(12), dp(6), dp(6), dp(6))
            }
            row.addView(TextView(this).apply {
                text = item.text
                setTextColor(kbTheme.text)
                textSize = 15f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setOnClickListener { currentInputConnection?.commitText(item.text, 1) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val pin = IconView(
                this, Ic.PIN, circle = true,
                iconColor = if (item.pinned) kbTheme.accent else kbTheme.text,
                circleColor = Themes.alpha(kbTheme.text, 0x22), filled = item.pinned
            )
            pin.setOnClickListener { ClipStore.togglePin(this, item.text); refresh() }
            val del = IconView(this, Ic.TRASH, circle = true, iconColor = kbTheme.text, circleColor = Themes.alpha(kbTheme.text, 0x22))
            del.setOnClickListener { ClipStore.remove(this, item.text); refresh() }
            for (b in listOf(pin, del)) {
                val lp = LinearLayout.LayoutParams(dp(34), dp(34))
                lp.leftMargin = dp(6)
                row.addView(b, lp)
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(4)
            col.addView(row, lp)
        }
        scroll.addView(col)
        root.addView(scroll)
        val bottom = newRow()
        bottom.addView(key("ABC", 2f, special = true) { switchPanel(Panel.LETTERS) })
        bottom.addView(key("Clear", 2f, special = true) { ClipStore.clearUnpinned(this); refresh() })
        bottom.addView(key("space", 3f) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(key("⌫", 2f, special = true, repeat = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(bottom)
    }

    private var styleFont = -1
    private var styleTab = 0
    private var styleDeco = -1
    private var styleScrollY = 0

    private fun setStyleFont(i: Int) {
        styleFont = i
        prefs.edit().putInt(Prefs.STYLE_FONT, i).apply()
        toast(if (i < 0) "Stylish font off" else "Stylish: " + Stylish.fonts[i].name)
        refresh()
    }

    private fun pickFont(i: Int) {
        val ic = currentInputConnection
        val sel = ic?.getSelectedText(0)
        if (ic != null && sel != null && sel.isNotEmpty()) {
            ic.commitText(Stylish.apply(i, sel.toString()), 1)
        } else {
            setStyleFont(i)
        }
    }

    private fun setStyleDeco(i: Int) {
        styleDeco = i
        prefs.edit().putInt(Prefs.STYLE_DECO, i).apply()
        toast(if (i < 0) "Decoration off" else "Decoration on")
        refresh()
    }

    private fun applyDeco(i: Int) {
        commitComposing()
        val ic = currentInputConnection ?: return
        val d = Stylish.decos[i]
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) {
            ic.commitText(Stylish.decorate(i, sel.toString()), 1)
            return
        }
        styleDeco = i
        prefs.edit().putInt(Prefs.STYLE_DECO, i).apply()
        ic.commitText(d.pre, 1)
        ic.commitText(d.suf, 0)
        refresh()
    }

    /** Stylish fonts and decorations panel. */
    private fun stylePanel(root: LinearLayout) {
        val gridH = dp(keyHeightDp) * 3
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34))
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        for ((i, name) in listOf("Stylish Fonts", "Stylish Decorations").withIndex()) {
            val on = styleTab == i
            tabs.addView(TextView(this).apply {
                text = name
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(if (on) kbTheme.accent else Themes.alpha(kbTheme.text, 0xB0))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(if (on) Themes.alpha(kbTheme.accent, 0x30) else 0)
                }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { styleTab = i; styleScrollY = 0; refresh() }
            })
        }
        root.addView(tabs)
        val scroll = android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, gridH - dp(34))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val labels = ArrayList<String>()
        val picked = ArrayList<Boolean>()
        val actions = ArrayList<() -> Unit>()
        if (styleTab == 0) {
            labels.add("Disable"); picked.add(styleFont < 0); actions.add { setStyleFont(-1) }
            for (i in Stylish.fonts.indices) {
                labels.add(Stylish.apply(i, "Abc xyz 123")); picked.add(styleFont == i); actions.add { pickFont(i) }
            }
        } else {
            labels.add("Disable"); picked.add(styleDeco < 0); actions.add { setStyleDeco(-1) }
            for (i in Stylish.decos.indices) {
                labels.add(Stylish.decorate(i, "Abc")); picked.add(styleDeco == i); actions.add { applyDeco(i) }
            }
        }
        val cols = if (styleTab == 0) 2 else 3
        var idx = 0
        while (idx < labels.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0 until cols) {
                val k = idx + j
                if (k < labels.size) {
                    val pill = TextView(this).apply {
                        text = labels[k]
                        gravity = Gravity.CENTER
                        textSize = 14f
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        setTextColor(kbTheme.text)
                        setPadding(dp(6), 0, dp(6), 0)
                        background = GradientDrawable().apply {
                            cornerRadius = dp(20).toFloat()
                            setColor(Themes.alpha(kbTheme.key, if (picked[k]) 0xFF else 0xB0))
                            setStroke(dp(2), if (picked[k]) kbTheme.accent else 0x00000000)
                        }
                        val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                        layoutParams = lp
                        setOnClickListener { styleScrollY = scroll.scrollY; feedback(this); actions[k]() }
                    }
                    row.addView(pill)
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, dp(40), 1f))
                }
            }
            col.addView(row)
            idx += cols
        }
        run {
            col.addView(TextView(this).apply {
                text = if (styleTab == 0) "Tap a style, then type in English. Select text first to convert it." else "Tap a decoration, then type in Sinhala or English. Select text first to wrap it."
                setTextColor(Themes.alpha(kbTheme.text, 0x90))
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(6))
            })
        }
        scroll.addView(col)
        root.addView(scroll)
        scroll.post { scroll.scrollTo(0, styleScrollY) }
        val bottom = newRow()
        bottom.addView(key("ABC", 2f, special = true) { switchPanel(Panel.LETTERS) })
        bottom.addView(key("space", 4f) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(key("⌫", 2f, special = true, repeat = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(bottom)
    }

    /** Cycles Normal, Fast, Ultra fast. */
    private fun toggleFast() {
        if (ultra) {
            ultra = false
            fast = false
            repeatMs = 55L
            repeatDelay = 380L
            toast("Normal typing")
        } else if (fast) {
            ultra = true
            repeatMs = 24L
            repeatDelay = 260L
            toast("Ultra fast typing")
        } else {
            fast = true
            toast("Fast typing")
        }
        prefs.edit().putBoolean(Prefs.FAST, fast).putBoolean(Prefs.ULTRA, ultra).apply()
        refresh()
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350L) {
            capsLock = true
            shift = true
        } else if (capsLock) {
            capsLock = false
            shift = false
        } else {
            shift = !shift
        }
        lastShiftTap = now
        updateShiftUi()
    }

    private fun onLetter(base: Char) {
        val up = shift || capsLock
        val c = if (up) base.uppercaseChar() else base
        if (shift && !capsLock) {
            shift = false
            updateShiftUi()
        }
        if (sinhalaMode) {
            buffer.append(c)
            refreshComposing()
        } else {
            currentInputConnection?.commitText(Stylish.mark(styleDeco, if (styleFont >= 0) Stylish.apply(styleFont, c.toString()) else c.toString()), 1)
            scheduleEnSuggest()
        }
    }

    private fun onBackspace() {
        if (buffer.isNotEmpty()) {
            buffer.deleteCharAt(buffer.length - 1)
            if (buffer.isEmpty()) {
                currentInputConnection?.commitText("", 1)
                updateSuggestions()
            } else {
                refreshComposing()
            }
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            scheduleEnSuggest()
        }
    }

    private fun onSpace() {
        if (!sinhalaMode && buffer.isEmpty()) learnEnglish(currentEnWord())
        commitComposing()
        val ic = currentInputConnection ?: return
        if (doubleSpace) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' &&
                before[0] != ' ' && before[0] !in ".,!?;:"
            ) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                autoCapFromContext()
                scheduleEnSuggest()
                return
            }
        }
        ic.commitText(" ", 1)
        autoCapFromContext()
        scheduleEnSuggest()
    }

    private fun onSymbol(s: String) {
        commitComposing()
        currentInputConnection?.commitText(s, 1)
        autoCapFromContext()
        scheduleEnSuggest()
    }

    private fun onEnter() {
        commitComposing()
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
            ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        autoCapFromContext()
        scheduleEnSuggest()
    }

    private fun onGlyph(g: String, kind: String) {
        feedback(inputRoot)
        commitComposing()
        currentInputConnection?.commitText(g, 1)
        GlyphData.addRecent(applicationContext, kind, g)
    }

    private fun pick(word: String) {
        handler.removeCallbacks(sugRunnable)
        currentInputConnection?.commitText(Stylish.markText(styleDeco, word) + " ", 1)
        learn(word)
        buffer.clear()
        updateSuggestions()
    }

    private fun commitComposing() {
        handler.removeCallbacks(sugRunnable)
        if (buffer.isEmpty()) return
        val word = bestForm(Transliterator.guesses(buffer.toString()))
        currentInputConnection?.commitText(Stylish.markText(styleDeco, word), 1)
        learn(word)
        buffer.clear()
        updateSuggestions()
    }

    private fun autoCapFromContext() {
        if (!autoCap || sinhalaMode || capsLock) return
        val ei = currentInputEditorInfo ?: return
        if (ei.inputType == 0) return
        val mode = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        val want = mode != 0
        if (want != shift) {
            shift = want
            updateShiftUi()
        }
    }

    private fun learn(word: String) {
        if (!learnOn || word.length < 2 || word[0].code !in 0x0D80..0x0DFF) return
        val n = (learnedCache[word] ?: 0) + 1
        learnedCache[word] = n
        Prefs.learned(this).edit().putInt(word, n).apply()
    }
}

/**
 * The keyboard's height comes from the keys only (child 1). The animated background (child 0)
 * is stretched to exactly that size, so it can never make the keyboard window taller.
 */
private class KeyboardFrame(context: Context) : FrameLayout(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val bg = getChildAt(0)
        val content = getChildAt(1)
        content.measure(
            MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        )
        val h = content.measuredHeight
        bg.measure(
            MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
        )
        for (i in 2 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(w, h)
    }
}
