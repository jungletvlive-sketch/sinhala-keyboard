package lk.example.sinhalakeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

class SinhalaKeyboardService : InputMethodService() {

    private data class Theme(val bg: Int, val key: Int, val special: Int, val text: Int, val accent: Int)

    private val themes = listOf(
        Theme(0xFF1B1B1F.toInt(), 0xFF2E2F36.toInt(), 0xFF3C3E48.toInt(), Color.WHITE, 0xFF4FC3F7.toInt()), // Dark
        Theme(0xFFE8EAF0.toInt(), Color.WHITE, 0xFFCDD1DC.toInt(), 0xFF111111.toInt(), 0xFF1976D2.toInt()), // Light
        Theme(0xFF0B3C5D.toInt(), 0xFF1D5F8A.toInt(), 0xFF0E2C44.toInt(), Color.WHITE, 0xFFFFC857.toInt())  // Ocean
    )

    private val prefs by lazy { getSharedPreferences("kb", Context.MODE_PRIVATE) }
    private var themeIndex = 0
    private var sinhalaMode = true
    private var shift = false
    private var showEmoji = false
    private val buffer = StringBuilder()

    private val emojis = listOf(
        "😀", "😂", "🤣", "😍", "😘", "😎", "🥰", "😢", "😭", "😡", "🤔", "😴",
        "👍", "👏", "🙏", "💪", "🔥", "❤️", "💔", "🎉", "🌴", "🌊", "🐟", "🎣",
        "☀️", "🌙", "⭐", "🍛", "🍚", "☕", "🏏", "🇱🇰", "😅", "😉", "🙌", "💯"
    )

    private val words = listOf(
        "මම", "මට", "ඔයා", "ඔයාට", "ඔබ", "කොහොමද", "මොකක්ද", "මොකද", "හරි", "හොඳයි",
        "ස්තූතියි", "ආයුබෝවන්", "ශ්‍රී ලංකා", "ගෙදර", "යනවා", "එනවා", "කරනවා", "බලනවා",
        "කන්න", "බොන්න", "ඉන්නවා", "තියෙනවා", "නැහැ", "ඔව්", "කවදාද", "කොහෙද", "ලස්සනයි",
        "ආදරෙයි", "යාළුවා", "අම්මා", "තාත්තා", "අයියා", "අක්කා", "නංගි", "මල්ලි", "මාළු", "මුහුද"
    )

    override fun onCreateInputView(): View {
        themeIndex = prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)
        return buildView()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        commitComposing()
        super.onFinishInputView(finishingInput)
    }

    private val t get() = themes[themeIndex]
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun refresh() = setInputView(buildView())

    // ---------- UI ----------

    private fun buildView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(t.bg)
            setPadding(dp(4), dp(4), dp(4), dp(6))
        }
        root.addView(suggestionBar())
        if (showEmoji) emojiPanel(root) else letterRows(root)
        return root
    }

    private fun suggestionBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
            layoutParams = LinearLayout.LayoutParams(-1, dp(44))
        }
        if (sinhalaMode && buffer.isNotEmpty()) {
            val current = Transliterator.convert(buffer.toString())
            val matches = words.filter { it.startsWith(current) && it != current }.take(6)
            val items = listOf(current) + matches
            for (w in items) {
                row.addView(label(w, t.accent, 0f).also {
                    it.setPadding(dp(14), 0, dp(14), 0)
                    it.setOnClickListener { pick(w) }
                })
            }
        }
        return scroll
    }

    private fun letterRows(root: LinearLayout) {
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        for ((idx, r) in rows.withIndex()) {
            val row = newRow()
            if (idx == 2) row.addView(key(if (shift) "⬆" else "⇧", 1.5f, special = true) { shift = !shift; refresh() })
            for (ch in r) {
                val shown = if (shift) ch.uppercaseChar() else ch
                row.addView(key(shown.toString(), 1f) { onLetter(ch) })
            }
            if (idx == 2) row.addView(key("⌫", 1.5f, special = true) { onBackspace() })
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("🙂", 1.2f, special = true) { commitComposing(); showEmoji = true; refresh() })
        bottom.addView(key("🎨", 1.2f, special = true) {
            themeIndex = (themeIndex + 1) % themes.size
            prefs.edit().putInt("theme", themeIndex).apply()
            refresh()
        })
        bottom.addView(key(if (sinhalaMode) "සිං" else "EN", 1.2f, special = true) {
            commitComposing(); sinhalaMode = !sinhalaMode; refresh()
        })
        bottom.addView(key("space", 4f) { onSpace() })
        bottom.addView(key(".", 1f) { onSymbol(".") })
        bottom.addView(key("↵", 1.5f, special = true) { onEnter() })
        root.addView(bottom)
    }

    private fun emojiPanel(root: LinearLayout) {
        for (chunk in emojis.chunked(6)) {
            val row = newRow()
            for (e in chunk) row.addView(key(e, 1f) { currentInputConnection?.commitText(e, 1) })
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("ABC", 2f, special = true) { showEmoji = false; refresh() })
        bottom.addView(key("space", 5f) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(key("⌫", 2f, special = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(bottom)
    }

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, dp(48))
    }

    private fun label(text: String, color: Int, weight: Float) = TextView(this).apply {
        this.text = text
        setTextColor(color)
        textSize = 18f
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(if (weight > 0) 0 else -2, -1, weight)
    }

    private fun key(text: String, weight: Float, special: Boolean = false, onClick: () -> Unit): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(if (special) t.special else t.key)
        }
        return TextView(this).apply {
            this.text = text
            setTextColor(t.text)
            textSize = 19f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER
            background = bg
            val lp = LinearLayout.LayoutParams(0, -1, weight)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    // ---------- Input logic ----------

    private fun onLetter(ch: Char) {
        val c = if (shift) ch.uppercaseChar() else ch
        val wasShift = shift
        shift = false
        if (sinhalaMode) {
            buffer.append(c)
            currentInputConnection?.setComposingText(Transliterator.convert(buffer.toString()), 1)
            refresh()
        } else {
            currentInputConnection?.commitText(c.toString(), 1)
            if (wasShift) refresh()
        }
    }

    private fun onBackspace() {
        if (buffer.isNotEmpty()) {
            buffer.deleteCharAt(buffer.length - 1)
            if (buffer.isEmpty()) currentInputConnection?.commitText("", 1)
            else currentInputConnection?.setComposingText(Transliterator.convert(buffer.toString()), 1)
            refresh()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun onSpace() {
        commitComposing()
        currentInputConnection?.commitText(" ", 1)
    }

    private fun onSymbol(s: String) {
        commitComposing()
        currentInputConnection?.commitText(s, 1)
    }

    private fun onEnter() {
        commitComposing()
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun pick(word: String) {
        currentInputConnection?.commitText("$word ", 1)
        buffer.clear()
        refresh()
    }

    private fun commitComposing() {
        if (buffer.isNotEmpty()) {
            currentInputConnection?.commitText(Transliterator.convert(buffer.toString()), 1)
            buffer.clear()
            refresh()
        }
    }
}
