package lk.example.sinhalakeyboard

import android.app.Activity
import android.os.Bundle

class FastTypingActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Fast Typing")
        c.addView(Ui.inputField(this, "Test your keyboard"))

        Ui.add(c, Ui.body(this, "Everything that makes typing quicker, in one place.", 14f), 12)

        Ui.add(c, Ui.heading(this, "SPEED"), 6)
        Ui.add(
            c,
            Ui.switchRow(
                this, "Ultra fast typing",
                "Fastest mode: keys react at once, suggestions wait until you pause, and backspace repeats quicker",
                Prefs.ULTRA, true
            ),
            6
        )
        Ui.add(
            c,
            Ui.switchRow(
                this, "Instant key press",
                "Types the moment your finger touches a key, without waiting for release",
                Prefs.FAST, true
            ),
            6
        )
        Ui.add(c, Ui.choiceRow(this, "Backspace repeat speed", listOf("Slow", "Normal", "Fast"), Prefs.REPEAT, 1), 8)

        Ui.add(c, Ui.heading(this, "SHORTCUTS"), 10)
        Ui.add(
            c,
            Ui.switchRow(this, "Double-space for full stop", "Tap space twice to add \". \"", Prefs.DOUBLE_SPACE, true),
            6
        )
        Ui.add(
            c,
            Ui.switchRow(this, "Auto-capitalise (English)", "Capital letter at the start of a sentence", Prefs.AUTO_CAP, true),
            8
        )
        Ui.add(c, Ui.switchRow(this, "Number row", "Show 1 to 0 above the letters", Prefs.NUMBER_ROW, false), 8)

        Ui.add(c, Ui.heading(this, "KEYBOARD TOOLBAR"), 10)
        Ui.add(
            c,
            Ui.body(
                this,
                "When you are not typing, the bar above the keys shows quick buttons:\n\n" +
                    "⚙  Open this app\n🎨  Next theme\n🌌  Next live wallpaper\n" +
                    "⚡  Cycle Normal, Fast and Ultra fast typing\n😀  Emojis\n✨  Epic symbols",
                14f
            ),
            6
        )
        Ui.add(c, Ui.body(this, "Changes apply the next time the keyboard opens.", 13f), 14)
    }
}
