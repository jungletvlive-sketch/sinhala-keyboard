package lk.example.sinhalakeyboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Type some English text, see it in every stylish font and decoration, tap one to copy it. */
class StylishActivity : Activity() {

    private lateinit var list: LinearLayout
    private var text = "Akuru Pro"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Stylish Text")
        val input = Ui.inputField(this, "Type your text here")
        input.setText(text)
        c.addView(input)
        Ui.add(c, Ui.body(this, "Tap any style to copy it. On the keyboard, tap the Aa button to type in these fonts and add decorations. Fonts work on English letters and numbers.", 13f), 12)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.add(c, list, 6)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                text = s?.toString() ?: ""
                render()
            }
        })
        render()
    }

    private fun render() {
        list.removeAllViews()
        val t = if (text.isEmpty()) "Abc" else text
        list.addView(Ui.heading(this, "FONTS"))
        for (i in Stylish.fonts.indices) list.addView(row(Stylish.fonts[i].name, Stylish.apply(i, t)))
        list.addView(Ui.heading(this, "DECORATIONS"))
        for (i in Stylish.decos.indices) list.addView(row("Decoration " + (i + 1), Stylish.decorate(i, t)))
    }

    private fun row(name: String, result: String): LinearLayout {
        val card = Ui.card(this)
        card.addView(TextView(this).apply {
            this.text = name
            textSize = 11f
            setTextColor(Ui.MUTED)
        })
        card.addView(TextView(this).apply {
            this.text = result
            textSize = 19f
            setTextColor(Ui.TEXT)
            setPadding(0, Ui.dp(this@StylishActivity, 4), 0, 0)
        })
        val lp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        lp.setMargins(0, Ui.dp(this, 5), 0, 0)
        card.layoutParams = lp
        card.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("stylish", result))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        return card
    }
}
