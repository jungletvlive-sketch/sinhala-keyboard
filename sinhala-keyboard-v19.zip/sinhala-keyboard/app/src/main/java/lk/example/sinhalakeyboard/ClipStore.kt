package lk.example.sinhalakeyboard

import android.content.Context

class ClipItem(val text: String, val pinned: Boolean)

/** Copied text history. Pinned items stay at the top and are never removed automatically. */
object ClipStore {
    private const val SEP = "\u0001"
    private const val MAX = 30

    private fun read(ctx: Context, key: String): MutableList<String> {
        val s = Prefs.of(ctx).getString(key, "") ?: ""
        return if (s.isEmpty()) mutableListOf() else s.split(SEP).toMutableList()
    }

    private fun write(ctx: Context, key: String, list: List<String>) {
        Prefs.of(ctx).edit().putString(key, list.joinToString(SEP)).apply()
    }

    fun list(ctx: Context): List<ClipItem> {
        val pins = read(ctx, "clip_pins")
        val recent = read(ctx, "clip_recent").filter { it !in pins }
        return pins.map { ClipItem(it, true) } + recent.map { ClipItem(it, false) }
    }

    fun add(ctx: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty() || t.length > 1000) return
        if (read(ctx, "clip_pins").contains(t)) return
        val recent = read(ctx, "clip_recent")
        recent.remove(t)
        recent.add(0, t)
        write(ctx, "clip_recent", recent.take(MAX))
    }

    fun togglePin(ctx: Context, text: String) {
        val pins = read(ctx, "clip_pins")
        val recent = read(ctx, "clip_recent")
        if (pins.remove(text)) {
            recent.remove(text)
            recent.add(0, text)
        } else {
            recent.remove(text)
            pins.add(0, text)
        }
        write(ctx, "clip_pins", pins)
        write(ctx, "clip_recent", recent)
    }

    fun remove(ctx: Context, text: String) {
        val pins = read(ctx, "clip_pins")
        val recent = read(ctx, "clip_recent")
        pins.remove(text)
        recent.remove(text)
        write(ctx, "clip_pins", pins)
        write(ctx, "clip_recent", recent)
    }

    fun clearUnpinned(ctx: Context) = write(ctx, "clip_recent", emptyList())
}
