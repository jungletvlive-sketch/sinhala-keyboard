package lk.example.sinhalakeyboard

import android.app.Activity
import android.content.Context
import android.animation.ValueAnimator
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.graphics.Typeface
import android.view.animation.LinearInterpolator
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

object Ui {
    /** true = dark screens, false = light screens. Set by [screen] from the "App mode" setting. */
    var dark = true

    val BG: Int get() = if (dark) 0xFF14131A.toInt() else 0xFFF2F3F8.toInt()
    val CARD: Int get() = if (dark) 0xFF1F1E29.toInt() else 0xFFFFFFFF.toInt()
    val CHIP: Int get() = if (dark) 0xFF2B2A38.toInt() else 0xFFE3E5EF.toInt()
    val OUTLINE: Int get() = if (dark) 0xFF3A3948.toInt() else 0xFFD0D3E0.toInt()
    val TEXT: Int get() = if (dark) 0xFFFFFFFF.toInt() else 0xFF16151D.toInt()
    val MUTED: Int get() = if (dark) 0xFFA9A8B8.toInt() else 0xFF5A5C70.toInt()
    val ACCENT: Int get() = if (dark) 0xFF7C6CFF.toInt() else 0xFF5B4BD6.toInt()

    /** 0 = dark, 1 = light, 2 = follow the phone. */
    fun applyMode(ctx: Context) {
        dark = when (Prefs.of(ctx).getInt(Prefs.APP_MODE, 0)) {
            1 -> false
            2 -> (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES
            else -> true
        }
    }

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun alpha(color: Int, a: Int): Int = Themes.alpha(color, a)

    /** Full-screen page with a header; returns the scrolling content column. */
    fun screen(activity: Activity, title: String, back: Boolean = true): LinearLayout {
        applyMode(activity)
        activity.window.statusBarColor = BG
        activity.window.navigationBarColor = BG
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            var f = activity.window.decorView.systemUiVisibility
            f = if (dark) f and android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            else f or android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                f = if (dark) f and android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                else f or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            activity.window.decorView.systemUiVisibility = f
        }
        activity.window.setBackgroundDrawable(ColorDrawable(BG))
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(activity, 8), dp(activity, 10), dp(activity, 8), dp(activity, 6))
        }
        if (back) {
            bar.addView(TextView(activity).apply {
                text = "←"
                textSize = 24f
                setTextColor(TEXT)
                setPadding(dp(activity, 12), dp(activity, 4), dp(activity, 16), dp(activity, 4))
                setOnClickListener { activity.finish() }
            })
        } else {
            bar.setPadding(dp(activity, 20), dp(activity, 14), dp(activity, 8), dp(activity, 6))
        }
        bar.addView(TextView(activity).apply {
            text = title
            textSize = 22f
            setTextColor(TEXT)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(bar)
        val content = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 28))
        }
        val scroll = ScrollView(activity)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        activity.setContentView(root)
        return content
    }

    fun add(parent: LinearLayout, v: View, topDp: Int = 10) {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(parent.context, topDp)
        parent.addView(v, lp)
    }

    fun heading(ctx: Context, text: String): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 13f
        setTextColor(ACCENT)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(ctx, 4), dp(ctx, 12), 0, 0)
    }

    fun body(ctx: Context, text: String, size: Float = 15f): TextView = TextView(ctx).apply {
        this.text = text
        textSize = size
        setTextColor(MUTED)
        setLineSpacing(0f, 1.15f)
    }

    fun label(ctx: Context, text: String): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 16f
        setTextColor(TEXT)
    }

    fun pill(color: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = 1000f
        setColor(color)
    }

    fun card(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            cornerRadius = dp(ctx, 14).toFloat()
            setColor(CARD)
        }
        setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
    }

    fun button(ctx: Context, text: String, color: Int = ACCENT, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = 15f
            val lum = 0.299 * ((color shr 16) and 0xFF) + 0.587 * ((color shr 8) and 0xFF) + 0.114 * (color and 0xFF)
            setTextColor(if (lum > 140) 0xFF101010.toInt() else 0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = pill(color)
            setPadding(dp(ctx, 16), dp(ctx, 12), dp(ctx, 16), dp(ctx, 12))
            setOnClickListener { onClick() }
        }

    fun inputField(ctx: Context, hint: String): EditText = EditText(ctx).apply {
        this.hint = hint
        setHintTextColor(MUTED)
        setTextColor(TEXT)
        textSize = 16f
        background = GradientDrawable().apply {
            cornerRadius = dp(ctx, 8).toFloat()
            setColor(0x00000000)
            setStroke(dp(ctx, 1), 0xFF8A8999.toInt())
        }
        setPadding(dp(ctx, 14), dp(ctx, 14), dp(ctx, 14), dp(ctx, 14))
    }

    fun switchRow(
        ctx: Context,
        title: String,
        subtitle: String?,
        key: String,
        def: Boolean,
        onChanged: ((Boolean) -> Unit)? = null
    ): View {
        val prefs = Prefs.of(ctx)
        val row = card(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(ctx, title))
        if (subtitle != null) texts.addView(body(ctx, subtitle, 13f))
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(ctx)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChanged?.invoke(checked)
        }
        row.addView(sw)
        return row
    }

    fun choiceRow(
        ctx: Context,
        title: String,
        options: List<String>,
        key: String,
        def: Int,
        onChanged: ((Int) -> Unit)? = null
    ): View {
        val prefs = Prefs.of(ctx)
        val card = card(ctx)
        card.addView(label(ctx, title))
        val chips = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val views = ArrayList<TextView>()
        fun style(sel: Int) {
            for ((i, v) in views.withIndex()) {
                v.setTextColor(if (i == sel) 0xFF101010.toInt() else TEXT)
                v.background = pill(if (i == sel) ACCENT else CHIP)
            }
        }
        options.forEachIndexed { i, name ->
            val tv = TextView(ctx).apply {
                text = name
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(dp(ctx, 16), dp(ctx, 8), dp(ctx, 16), dp(ctx, 8))
                setOnClickListener {
                    prefs.edit().putInt(key, i).apply()
                    style(i)
                    onChanged?.invoke(i)
                }
            }
            views.add(tv)
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.rightMargin = dp(ctx, 8)
            lp.topMargin = dp(ctx, 10)
            chips.addView(tv, lp)
        }
        style(prefs.getInt(key, def).coerceIn(0, options.size - 1))
        card.addView(chips)
        return card
    }

    fun tile(ctx: Context, glyph: String, label: String, color: Int, onClick: () -> Unit): View {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(ctx, 4), dp(ctx, 12), dp(ctx, 4), dp(ctx, 12))
        }
        val circle = FrameLayout(ctx)
        circle.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(alpha(color, 0x22))
            setStroke(dp(ctx, 2), alpha(color, 0xB0))
        }
        circle.addView(TextView(ctx).apply {
            text = glyph
            textSize = 34f
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(circle, LinearLayout.LayoutParams(dp(ctx, 84), dp(ctx, 84)))
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = dp(ctx, 8)
        col.addView(TextView(ctx).apply {
            text = label
            textSize = 14f
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            maxLines = 2
        }, lp)
        col.setOnClickListener { onClick() }
        return col
    }

    /** Home screen tile with a drawn icon instead of an emoji. */
    fun tileIcon(ctx: Context, icon: Ic, label: String, color: Int, onClick: () -> Unit): View {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(ctx, 4), dp(ctx, 12), dp(ctx, 4), dp(ctx, 12))
        }
        val circle = FrameLayout(ctx)
        circle.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(alpha(color, 0x55), alpha(color, 0x18))
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(ctx, 2), alpha(color, 0xC0))
        }
        val iv = IconView(ctx, icon, circle = false, iconColor = color or 0xFF000000.toInt())
        circle.addView(iv, FrameLayout.LayoutParams(dp(ctx, 46), dp(ctx, 46), Gravity.CENTER))
        col.addView(circle, LinearLayout.LayoutParams(dp(ctx, 84), dp(ctx, 84)))
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = dp(ctx, 8)
        col.addView(TextView(ctx).apply {
            text = label
            textSize = 14f
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            maxLines = 2
        }, lp)
        col.setOnClickListener { onClick() }
        return col
    }

    /** Text filled with a moving rainbow. */
    fun rgbText(ctx: Context, text: String, sizeSp: Float, bold: Boolean = true): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = sizeSp
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        val tw = tv.paint.measureText(text).coerceAtLeast(1f)
        val shader = LinearGradient(0f, 0f, tw, 0f, Rgb.rainbow, null, Shader.TileMode.REPEAT)
        tv.paint.shader = shader
        val m = Matrix()
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 3500
        anim.repeatCount = ValueAnimator.INFINITE
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener {
            m.setTranslate((it.animatedValue as Float) * tw, 0f)
            shader.setLocalMatrix(m)
            tv.invalidate()
        }
        tv.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) { anim.start() }
            override fun onViewDetachedFromWindow(v: View) { anim.cancel() }
        })
        return tv
    }

    /** Lays views out in rows with [perRow] equal columns. */
    fun grid(ctx: Context, views: List<View>, perRow: Int, gapDp: Int = 6): LinearLayout {
        val out = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        for (chunk in views.chunked(perRow)) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until perRow) {
                val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
                lp.setMargins(dp(ctx, gapDp), dp(ctx, gapDp), dp(ctx, gapDp), dp(ctx, gapDp))
                if (i < chunk.size) row.addView(chunk[i], lp) else row.addView(View(ctx), lp)
            }
            out.addView(row)
        }
        return out
    }
}
