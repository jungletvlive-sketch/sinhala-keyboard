package lk.example.sinhalakeyboard

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar

/** A simple built-in browser: address bar, back, forward, reload, home and "open elsewhere". */
class BrowserActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.applyMode(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        window.setBackgroundDrawable(ColorDrawable(Ui.BG))
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            var f = window.decorView.systemUiVisibility
            f = if (Ui.dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            window.decorView.systemUiVisibility = f
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }

        // top bar: back to app + address field
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(context, 6), Ui.dp(context, 8), Ui.dp(context, 10), Ui.dp(context, 6))
        }
        top.addView(
            iconButton(Ic.CHEVRON, 90f) { finish() },
            LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40))
        )
        address = Ui.inputField(this, "Search or type a web address")
        address.setSingleLine(true)
        address.imeOptions = EditorInfo.IME_ACTION_GO
        address.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        address.setOnEditorActionListener { _, action, ev ->
            if (action == EditorInfo.IME_ACTION_GO || (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER)) {
                go(address.text.toString())
                true
            } else false
        }
        top.addView(address, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 3)))

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.settings.loadWithOverviewMode = true
        web.settings.useWideViewPort = true
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
                if (!address.hasFocus()) address.setText(url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
                if (!address.hasFocus()) address.setText(url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }
        }
        root.addView(web, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        // bottom bar
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Ui.CARD)
            setPadding(0, Ui.dp(context, 6), 0, Ui.dp(context, 6))
        }
        fun add(ic: Ic, rot: Float = 0f, onClick: () -> Unit) {
            val lp = LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f)
            bottom.addView(iconButton(ic, rot, onClick), lp)
        }
        add(Ic.CHEVRON, 90f) { if (web.canGoBack()) web.goBack() }
        add(Ic.CHEVRON, -90f) { if (web.canGoForward()) web.goForward() }
        add(Ic.BOLT) { web.reload() }
        add(Ic.GLOBE) { go(HOME) }
        add(Ic.DOWNLOAD, 270f) {
            val u = web.url
            if (u != null) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        }
        root.addView(bottom, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        setContentView(root)
        val start = intent?.dataString
        if (savedInstanceState != null) web.restoreState(savedInstanceState) else go(start ?: HOME)
    }

    private fun iconButton(ic: Ic, rotate: Float, onClick: () -> Unit): View {
        val v = IconView(
            this, ic, circle = true,
            iconColor = Ui.TEXT,
            circleColor = Ui.alpha(Ui.TEXT, 0x18)
        )
        v.rotation = rotate
        v.setOnClickListener { onClick() }
        val wrap = LinearLayout(this).apply { gravity = Gravity.CENTER }
        wrap.addView(v, LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)))
        return wrap
    }

    private fun go(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(' ') && t.contains('.') -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        address.clearFocus()
        web.loadUrl(url)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    private companion object {
        const val HOME = "https://www.google.com"
    }
}
