package lk.example.sinhalakeyboard

import android.app.Activity
import android.os.Bundle

class RgbActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "RGB Lights")
        c.addView(Ui.inputField(this, "Test your keyboard"))
        Ui.add(c, Ui.body(this, "Colour-changing lights for your keyboard. Border draws a glowing rainbow frame, Keys lights the edge of every key, Both uses both.", 14f), 12)
        Ui.add(c, Ui.choiceRow(this, "Lighting", listOf("Off", "Border", "Keys", "Both"), Prefs.RGB, 0), 12)
        Ui.add(c, Ui.choiceRow(this, "Speed", listOf("Slow", "Medium", "Fast"), Prefs.RGB_SPEED, 1), 8)
        Ui.add(c, Ui.body(this, "Tip: tap the rainbow button on the keyboard toolbar to switch the lights quickly. RGB uses a little more battery.", 13f), 14)
    }
}
