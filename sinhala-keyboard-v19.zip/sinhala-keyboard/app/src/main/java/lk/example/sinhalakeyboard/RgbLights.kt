package lk.example.sinhalakeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.View

object Rgb {
    const val OFF = 0
    const val BORDER = 1
    const val KEYS = 2
    const val BOTH = 3
    val modes = listOf("Off", "Border", "Key lights", "Border + Keys")

    /** Degrees of hue that pass per second. */
    fun speed(ctx: Context): Float = when (Prefs.of(ctx).getInt(Prefs.RGB_SPEED, 1)) {
        0 -> 40f
        2 -> 160f
        else -> 90f
    }

    fun hue(t: Float, offset: Float, speed: Float): Float = ((t * speed + offset) % 360f + 360f) % 360f

    fun color(hue: Float, v: Float = 1f): Int = Color.HSVToColor(floatArrayOf(hue, 0.95f, v))

    val rainbow = intArrayOf(
        0xFFFF2D55.toInt(), 0xFFFF9500.toInt(), 0xFFFFE600.toInt(), 0xFF34E36B.toInt(),
        0xFF00D4FF.toInt(), 0xFF6A5CFF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFF2D55.toInt()
    )
}

/** A glowing rainbow border that travels around the edge of the keyboard. */
class RgbBorderView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val matrix = Matrix()
    private val rect = RectF()
    private var shader: SweepGradient? = null
    private val speed = Rgb.speed(context)
    private val d = context.resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (shader == null) shader = SweepGradient(w / 2, h / 2, Rgb.rainbow, null)
        val angle = (SystemClock.uptimeMillis() % 100000L) / 1000f * speed
        matrix.setRotate(angle, w / 2, h / 2)
        shader!!.setLocalMatrix(matrix)
        paint.shader = shader
        val r = 12f * d
        // soft glow: wide faint strokes first, a sharp line last
        val widths = floatArrayOf(10f, 6f, 3.2f, 1.6f)
        val alphas = intArrayOf(40, 80, 150, 255)
        for (i in widths.indices) {
            paint.strokeWidth = widths[i] * d
            paint.alpha = alphas[i]
            val inset = (widths[0] / 2f + 0.5f) * d
            rect.set(inset, inset, w - inset, h - inset)
            c.drawRoundRect(rect, r, r, paint)
        }
        postInvalidateOnAnimation()
    }
}

/** Key background: normal fill with a rainbow outline whose colour changes across the keyboard. */
class RgbKeyDrawable(
    private val view: View,
    private val fillColor: Int,
    private val pressedColor: Int,
    private val radius: Float,
    private val strokeW: Float,
    private val speed: Float
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = strokeW }
    private val rect = RectF()
    private var pressed = false

    override fun isStateful(): Boolean = true

    override fun onStateChange(state: IntArray): Boolean {
        val now = state.contains(android.R.attr.state_pressed)
        if (now == pressed) return false
        pressed = now
        invalidateSelf()
        return true
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val inset = strokeW / 2f
        rect.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
        fill.color = if (pressed) pressedColor else fillColor
        c.drawRoundRect(rect, radius, radius, fill)
        val parentTop = (view.parent as? View)?.top ?: 0
        val x = view.left + view.width / 2f
        val y = parentTop + view.height / 2f
        val t = (SystemClock.uptimeMillis() % 100000L) / 1000f
        val hue = Rgb.hue(t, x / 4f + y / 3f, speed)
        line.color = Rgb.color(hue)
        c.drawRoundRect(rect, radius, radius, line)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}
