package lk.example.sinhalakeyboard

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class WallpapersActivity : Activity() {

    private lateinit var container: LinearLayout
    private var kind = "2d"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        kind = intent.getStringExtra("kind") ?: "2d"
        val c = Ui.screen(this, when (kind) { "hd" -> "HD Wallpapers"; "live" -> "HD Live Themes"; else -> "2D Wallpapers" })
        c.addView(Ui.inputField(this, "Test your keyboard"))
        Ui.add(c, Ui.body(this, when (kind) {
            "hd" -> "Picture backgrounds for your keyboard. Tap one to apply it. A dark layer keeps the keys easy to read."
            "live" -> "Moving HD pictures with floating sparks, petals and light. Tap one to apply it."
            else -> "Animated 2D backgrounds drawn by the app. Tap one to apply it. Colours follow your theme."
        }, 13f), 12)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.add(c, container, 6)
        render()
    }

    private fun render() {
        val prefs = Prefs.of(this)
        val th = Themes.all[prefs.getInt(Prefs.THEME, 0).coerceIn(0, Themes.all.size - 1)]
        val sel = prefs.getInt(Prefs.WALLPAPER, 0).coerceIn(0, Wallpapers.names.size - 1)
        container.removeAllViews()
        val indices = when (kind) {
            "hd" -> listOf(0) + (Wallpapers.PHOTO_START until Wallpapers.LIVE_START)
            "live" -> listOf(0) + (Wallpapers.LIVE_START until Wallpapers.names.size)
            else -> (0 until Wallpapers.PHOTO_START).toList()
        }
        val cards = indices.map { i -> card(i, th, i == sel) }
        container.addView(Ui.grid(this, cards, 2, 6))
    }

    private fun card(index: Int, th: KbTheme, selected: Boolean): View {
        val ctx = this
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(ctx, 6)
            setPadding(p, p, p, p)
            background = GradientDrawable().apply {
                cornerRadius = Ui.dp(ctx, 16).toFloat()
                setColor(if (selected) Ui.alpha(th.accent, 0x33) else Ui.CARD)
                setStroke(Ui.dp(ctx, 2), if (selected) th.accent else 0x00000000)
            }
        }
        val p = KeyboardPreview(ctx)
        p.set(th, index)
        col.addView(p, LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(ctx, 110)))
        col.addView(TextView(ctx).apply {
            val n = Wallpapers.icons[index] + "  " + Wallpapers.names[index]
            text = if (selected) "$n  ✓" else n
            textSize = 14f
            setTextColor(Ui.TEXT)
            gravity = Gravity.CENTER
            setPadding(0, Ui.dp(ctx, 8), 0, Ui.dp(ctx, 4))
        })
        col.setOnClickListener {
            Prefs.of(ctx).edit().putInt(Prefs.WALLPAPER, index).apply()
            render()
        }
        return col
    }
}
