package lk.example.sinhalakeyboard

class KbTheme(
    val name: String,
    val bg1: Int,
    val bg2: Int,
    val key: Int,
    val special: Int,
    val text: Int,
    val accent: Int
)

object Themes {
    private fun c(v: Long): Int = v.toInt()

    val all: List<KbTheme> = listOf(
        KbTheme("Midnight", c(0xFF1B1B1F), c(0xFF111114), c(0xFF2E2F36), c(0xFF3C3E48), c(0xFFFFFFFF), c(0xFF4FC3F7)),
        KbTheme("Daylight", c(0xFFE8EAF0), c(0xFFD5D9E4), c(0xFFFFFFFF), c(0xFFCDD1DC), c(0xFF111111), c(0xFF1976D2)),
        KbTheme("Ocean", c(0xFF0B3C5D), c(0xFF062538), c(0xFF1D5F8A), c(0xFF0E2C44), c(0xFFFFFFFF), c(0xFFFFC857)),
        KbTheme("Sunset", c(0xFF3B1F2B), c(0xFF22111A), c(0xFF6D2E46), c(0xFF4A2338), c(0xFFFFFFFF), c(0xFFFF8A65)),
        KbTheme("Forest", c(0xFF14281D), c(0xFF0B1711), c(0xFF265C3F), c(0xFF0F1F16), c(0xFFFFFFFF), c(0xFFA5D6A7)),
        KbTheme("Rose", c(0xFFFCE4EC), c(0xFFF8BBD0), c(0xFFFFFFFF), c(0xFFF8BBD0), c(0xFF3E1F2B), c(0xFFD81B60)),
        KbTheme("AMOLED", c(0xFF000000), c(0xFF000000), c(0xFF1A1A1A), c(0xFF262626), c(0xFFFFFFFF), c(0xFF00E5FF)),
        KbTheme("Neon", c(0xFF0D0221), c(0xFF1A0536), c(0xFF241B4A), c(0xFF2F1F63), c(0xFFF5F5FF), c(0xFFFF2BD6)),
        KbTheme("Royal Purple", c(0xFF2A1B4D), c(0xFF170E2E), c(0xFF4A3480), c(0xFF352363), c(0xFFFFFFFF), c(0xFFFFD54F)),
        KbTheme("Lavender", c(0xFFEDE7F6), c(0xFFD1C4E9), c(0xFFFFFFFF), c(0xFFD1C4E9), c(0xFF2A1B4D), c(0xFF7E57C2)),
        KbTheme("Coffee", c(0xFF3E2723), c(0xFF2A1A17), c(0xFF5D4037), c(0xFF4E342E), c(0xFFFFF3E0), c(0xFFFFB74D)),
        KbTheme("Mint", c(0xFFE0F7F4), c(0xFFB2DFDB), c(0xFFFFFFFF), c(0xFFB2DFDB), c(0xFF00332E), c(0xFF00897B)),
        KbTheme("Lanka", c(0xFF5C0F26), c(0xFF3A0818), c(0xFF8D153A), c(0xFF00534E), c(0xFFFFFFFF), c(0xFFFFBE29)),
        KbTheme("Cyber", c(0xFF0A1F1C), c(0xFF03100E), c(0xFF12332E), c(0xFF1B4A43), c(0xFFCCFFF2), c(0xFF39FF14)),
        KbTheme("Sky", c(0xFFE3F2FD), c(0xFFBBDEFB), c(0xFFFFFFFF), c(0xFFBBDEFB), c(0xFF0D2B45), c(0xFF0288D1)),
        KbTheme("Obsidian Gold", c(0xFF0E0E10), c(0xFF050506), c(0xFF1C1C20), c(0xFF2A2A30), c(0xFFFFF1CC), c(0xFFFFC107)),
        KbTheme("Crimson", c(0xFF1A0508), c(0xFF0A0204), c(0xFF3A0D14), c(0xFF55141E), c(0xFFFFFFFF), c(0xFFFF1744)),
        KbTheme("Cyberpunk", c(0xFF0B0B1E), c(0xFF14062E), c(0xFF1D1B45), c(0xFF2D1A5E), c(0xFFF0F0FF), c(0xFF00F0FF)),
        KbTheme("Aurora", c(0xFF06201A), c(0xFF031410), c(0xFF0F3D33), c(0xFF16544A), c(0xFFE8FFF8), c(0xFF00E5A8)),
        KbTheme("Ice", c(0xFFEAF6FF), c(0xFFCFE8FA), c(0xFFFFFFFF), c(0xFFB9D9F2), c(0xFF0B2A44), c(0xFF1E88E5)),
        KbTheme("Graphite", c(0xFF2B2D31), c(0xFF1E1F23), c(0xFF3C3F45), c(0xFF4A4D55), c(0xFFFFFFFF), c(0xFFFF7043)),
        KbTheme("Galaxy", c(0xFF120C2E), c(0xFF05030F), c(0xFF2A1F5C), c(0xFF3A2C7A), c(0xFFFFFFFF), c(0xFFB388FF)),
        KbTheme("Peach", c(0xFFFFF1E6), c(0xFFFFD9BF), c(0xFFFFFFFF), c(0xFFFFCBA4), c(0xFF4A2511), c(0xFFFF6F3C)),
        KbTheme("Matrix", c(0xFF000A00), c(0xFF000500), c(0xFF06200A), c(0xFF0B3512), c(0xFF9CFFB0), c(0xFF00FF41)),
        KbTheme("Blue Steel", c(0xFF0D1B2A), c(0xFF070F18), c(0xFF1B2F47), c(0xFF27425F), c(0xFFE0ECF8), c(0xFF4DA3FF))
    )

    fun alpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)
}

object Wallpapers {
    val names = listOf(
        "None", "Aurora", "Starry Night", "Bubbles", "Rain",
        "Fireflies", "Ocean Waves", "Snowfall", "Gradient Flow", "Skull"
    )
    val icons = listOf("⬜", "🌌", "⭐", "🔵", "🌧", "✨", "🌊", "❄", "🌈", "💀")
}
