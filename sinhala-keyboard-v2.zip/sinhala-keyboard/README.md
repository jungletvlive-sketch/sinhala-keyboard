# සිංහල Keyboard (Android)

Singlish -> සිංහල typing keyboard, සිංහල word suggestions, themes (Dark / Light / Ocean) සහ emoji panel.

## Build කරන්න
1. Android Studio (Koala හෝ අලුත්) වලින් `sinhala-keyboard` folder එක open කරන්න.
2. Gradle sync වෙනකම් ඉන්න.
3. Phone එකේ USB debugging on කරලා Run ▶ කරන්න.
4. App එක open කරලා "Keyboard enable කරන්න" සහ "Keyboard තෝරන්න" ඔබන්න.

## Typing නීති
- `mama` -> මම, `oya` -> ඔය, `kohomada` -> කොහොමද
- ලොකු අකුරු: `T` ට, `D` ඩ, `N` ණ, `L` ළ, `S` ශ, `Sh` ෂ
- `th` ථ, `dh` ධ, `nd` ඳ, `mb` ඹ, `ng` ඟ

## Play Store එකට කලින්
- `applicationId` (`lk.example.sinhalakeyboard`) ඔයාගේම නමකට වෙනස් කරන්න.
- Privacy Policy එකක් ලියන්න: "typed data collect කරන්නේ නැහැ, internet permission නැහැ" කියලා.
- Release AAB එකක් හදන්න (Build > Generate Signed Bundle) සහ signing key එක ආරක්ෂා කරගන්න.
- App icon සහ screenshots ඕන.

## ඊළඟට දාන්න පුළුවන්
- Backspace hold කළාම දිගටම මැකීම
- ලොකු Sinhala word list එකක් (file එකකින්) සහ user ඉගෙනගන්න suggestions
- Sinhala (Wijesekara) layout
- Settings screen (key height, vibration)
