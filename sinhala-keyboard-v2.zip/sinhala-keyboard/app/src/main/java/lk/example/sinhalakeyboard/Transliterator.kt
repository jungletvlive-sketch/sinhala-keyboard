package lk.example.sinhalakeyboard

/**
 * Singlish -> Sinhala transliteration.
 * Capital letters give the retroflex/aspirated variants: T ට, D ඩ, N ණ, L ළ, S ශ.
 * Examples: "mama" -> මම, "oya" -> ඔය, "kohomada" -> කොහොමද
 */
object Transliterator {

    private val consonants = mapOf(
        "ndh" to "ඳ", "nd" to "ඳ", "mb" to "ඹ", "ng" to "ඟ",
        "kh" to "ඛ", "gh" to "ඝ", "ch" to "ච", "jh" to "ඣ",
        "Th" to "ඨ", "Dh" to "ඪ", "th" to "ථ", "dh" to "ධ",
        "ph" to "ඵ", "bh" to "භ", "Sh" to "ෂ",
        "k" to "ක", "g" to "ග", "c" to "ච", "j" to "ජ",
        "T" to "ට", "D" to "ඩ", "N" to "ණ",
        "t" to "ත", "d" to "ද", "n" to "න",
        "p" to "ප", "b" to "බ", "m" to "ම",
        "y" to "ය", "r" to "ර", "l" to "ල", "L" to "ළ",
        "v" to "ව", "w" to "ව", "s" to "ස", "S" to "ශ",
        "h" to "හ", "f" to "ෆ"
    )

    // independent vowel, vowel sign (empty = inherent 'a')
    private val vowels = mapOf(
        "aae" to Pair("ඈ", "ෑ"), "aa" to Pair("ආ", "ා"), "ae" to Pair("ඇ", "ැ"),
        "ai" to Pair("ඓ", "ෛ"), "au" to Pair("ඖ", "ෞ"),
        "ii" to Pair("ඊ", "ී"), "uu" to Pair("ඌ", "ූ"),
        "ee" to Pair("ඒ", "ේ"), "oo" to Pair("ඕ", "ෝ"),
        "a" to Pair("අ", ""), "i" to Pair("ඉ", "ි"), "u" to Pair("උ", "ු"),
        "e" to Pair("එ", "ෙ"), "o" to Pair("ඔ", "ො")
    )

    private const val HAL = "්"

    private fun matchConsonant(s: String, i: Int): Pair<String, Int>? {
        for (len in 3 downTo 1) {
            if (i + len <= s.length) {
                consonants[s.substring(i, i + len)]?.let { return Pair(it, len) }
            }
        }
        return null
    }

    private fun matchVowel(s: String, i: Int): Pair<Pair<String, String>, Int>? {
        for (len in 3 downTo 1) {
            if (i + len <= s.length) {
                vowels[s.substring(i, i + len)]?.let { return Pair(it, len) }
            }
        }
        return null
    }

    fun convert(input: String): String {
        val out = StringBuilder()
        var i = 0
        while (i < input.length) {
            val c = matchConsonant(input, i)
            if (c != null) {
                i += c.second
                val v = matchVowel(input, i)
                if (v != null) {
                    out.append(c.first).append(v.first.second)
                    i += v.second
                } else {
                    out.append(c.first).append(HAL)
                }
                continue
            }
            val v = matchVowel(input, i)
            if (v != null) {
                out.append(v.first.first)
                i += v.second
                continue
            }
            out.append(input[i])
            i++
        }
        return out.toString()
    }
}
