package lk.example.sinhalakeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SetupActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("kb", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        fun heading(s: String, size: Float = 16f) = TextView(this).apply {
            text = s
            textSize = size
            setPadding(0, dp(14), 0, dp(4))
        }

        layout.addView(heading("සිංහල Keyboard", 24f))
        layout.addView(heading("1. Keyboard enable කරලා, 2. select කරන්න."))
        layout.addView(Button(this).apply {
            text = "1. Keyboard enable කරන්න"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "2. Keyboard තෝරන්න"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        layout.addView(heading("Settings", 20f))
        layout.addView(Switch(this).apply {
            text = "Key එබුවම vibrate වෙන්න"
            isChecked = prefs.getBoolean("vibrate", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("vibrate", c).apply() }
        })
        layout.addView(Switch(this).apply {
            text = "Key click sound"
            isChecked = prefs.getBoolean("sound", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("sound", c).apply() }
        })

        layout.addView(heading("Key height (උස)"))
        val rg = RadioGroup(this)
        listOf("පොඩි", "මධ්‍යම", "ලොකු").forEach { n ->
            rg.addView(RadioButton(this).apply {
                id = View.generateViewId()
                text = n
            })
        }
        rg.check(rg.getChildAt(prefs.getInt("height", 1).coerceIn(0, 2)).id)
        rg.setOnCheckedChangeListener { group, checkedId ->
            val idx = group.indexOfChild(group.findViewById(checkedId))
            if (idx >= 0) prefs.edit().putInt("height", idx).apply()
        }
        layout.addView(rg)

        layout.addView(heading("මෙතන type කරලා බලන්න"))
        layout.addView(EditText(this).apply { hint = "mama oya kohomada" })

        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
