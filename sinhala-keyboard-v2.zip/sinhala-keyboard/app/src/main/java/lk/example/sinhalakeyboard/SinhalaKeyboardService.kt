package lk.example.sinhalakeyboard

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SinhalaKeyboardService : InputMethodService() {

    private data class Theme(
        val name: String,
        val bg: Int,
        val key: Int,
        val special: Int,
        val text: Int,
        val accent: Int
    )

    private enum class Panel { LETTERS, SYMBOLS, EMOJI }

    private val themes = listOf(
        Theme("Dark", 0xFF1B1B1F.toInt(), 0xFF2E2F36.toInt(), 0xFF3C3E48.toInt(), Color.WHITE, 0xFF4FC3F7.toInt()),
        Theme("Light", 0xFFE8EAF0.toInt(), Color.WHITE, 0xFFCDD1DC.toInt(), 0xFF111111.toInt(), 0xFF1976D2.toInt()),
        Theme("Ocean", 0xFF0B3C5D.toInt(), 0xFF1D5F8A.toInt(), 0xFF0E2C44.toInt(), Color.WHITE, 0xFFFFC857.toInt()),
        Theme("Sunset", 0xFF3B1F2B.toInt(), 0xFF6D2E46.toInt(), 0xFF4A2338.toInt(), Color.WHITE, 0xFFFF8A65.toInt()),
        Theme("Forest", 0xFF14281D.toInt(), 0xFF265C3F.toInt(), 0xFF0F1F16.toInt(), Color.WHITE, 0xFFA5D6A7.toInt()),
        Theme("Rose", 0xFFFCE4EC.toInt(), Color.WHITE, 0xFFF8BBD0.toInt(), 0xFF3E1F2B.toInt(), 0xFFD81B60.toInt()),
        Theme("AMOLED", Color.BLACK, 0xFF1A1A1A.toInt(), 0xFF262626.toInt(), Color.WHITE, 0xFF00E5FF.toInt())
    )

    private val prefs by lazy { getSharedPreferences("kb", MODE_PRIVATE) }
    private val learned by lazy { getSharedPreferences("learned", MODE_PRIVATE) }
    private val learnedCache = HashMap<String, Int>()
    private var builtinWords: List<String> = emptyList()

    private val handler = Handler(Looper.getMainLooper())
    private var suggestionRow: LinearLayout? = null

    private var themeIndex = 0
    private var sinhalaMode = true
    private var shift = false
    private var panel = Panel.LETTERS
    private val buffer = StringBuilder()

    private val emojis = listOf(
        "😀", "😂", "🤣", "😍", "😘", "😎", "🥰", "😢", "😭", "😡", "🤔", "😴",
        "👍", "👏", "🙏", "💪", "🔥", "❤️", "💔", "🎉", "🌴", "🌊", "🐟", "🎣",
        "☀️", "🌙", "⭐", "🍛", "🍚", "☕", "🏏", "🇱🇰", "😅", "😉", "🙌", "💯"
    )

    override fun onCreate() {
        super.onCreate()
        builtinWords = try {
            assets.open("words.txt").bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() }
        } catch (e: Exception) {
            emptyList()
        }
        for ((k, v) in learned.all) {
            if (v is Int) learnedCache[k] = v
        }
    }

    override fun onCreateInputView(): View {
        themeIndex = prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)
        return buildView()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) {
            themeIndex = prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)
            buffer.clear()
            panel = Panel.LETTERS
            shift = false
            refresh()
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        commitComposing()
        super.onFinishInputView(finishingInput)
    }

    private val t get() = themes[themeIndex]
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun refresh() = setInputView(buildView())

    private fun rowHeight() = dp(
        when (prefs.getInt("height", 1)) {
            0 -> 42
            2 -> 56
            else -> 48
        }
    )

    // ---------- UI ----------

    private fun buildView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(t.bg)
            setPadding(dp(4), dp(4), dp(4), dp(6))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        }
        suggestionRow = row
        root.addView(scroll)
        updateSuggestions()
        when (panel) {
            Panel.LETTERS -> letterRows(root)
            Panel.SYMBOLS -> symbolRows(root)
            Panel.EMOJI -> emojiPanel(root)
        }
        return root
    }

    private fun updateSuggestions() {
        val row = suggestionRow ?: return
        row.removeAllViews()
        if (!sinhalaMode || buffer.isEmpty()) return
        val current = Transliterator.convert(buffer.toString())
        val items = LinkedHashSet<String>()
        items.add(current)
        items.addAll(matches(current.removeSuffix("්"), current))
        for (w in items) {
            row.addView(label(w).also { it.setOnClickListener { _ -> pick(w) } })
        }
    }

    private fun matches(prefix: String, exclude: String): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val user = learnedCache.entries
            .filter { it.key.startsWith(prefix) && it.key != exclude }
            .sortedByDescending { it.value }
            .map { it.key }
        val builtin = builtinWords.filter { it.startsWith(prefix) && it != exclude }
        return (user + builtin).distinct().take(8)
    }

    private fun letterRows(root: LinearLayout) {
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        for ((idx, r) in rows.withIndex()) {
            val row = newRow()
            if (idx == 2) row.addView(key(if (shift) "⬆" else "⇧", 1.5f, special = true) { shift = !shift; refresh() })
            for (ch in r) {
                val shown = if (shift) ch.uppercaseChar() else ch
                row.addView(key(shown.toString(), 1f) { onLetter(ch) })
            }
            if (idx == 2) row.addView(key("⌫", 1.5f, special = true, repeat = true) { onBackspace() })
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("🙂", 1.1f, special = true) { commitComposing(); panel = Panel.EMOJI; refresh() })
        bottom.addView(key("🎨", 1.1f, special = true) {
            themeIndex = (themeIndex + 1) % themes.size
            prefs.edit().putInt("theme", themeIndex).apply()
            Toast.makeText(this, t.name, Toast.LENGTH_SHORT).show()
            refresh()
        })
        bottom.addView(key("?123", 1.3f, special = true) { commitComposing(); panel = Panel.SYMBOLS; refresh() })
        bottom.addView(key(if (sinhalaMode) "සිං" else "EN", 1.1f, special = true) {
            commitComposing(); sinhalaMode = !sinhalaMode; refresh()
        })
        bottom.addView(key(",", 0.9f) { onSymbol(",") })
        bottom.addView(key("space", 3f) { onSpace() })
        bottom.addView(key(".", 0.9f) { onSymbol(".") })
        bottom.addView(key("↵", 1.4f, special = true) { onEnter() })
        root.addView(bottom)
    }

    private fun symbolRows(root: LinearLayout) {
        val rows = listOf("1234567890", "@#\$%&-+()/", "!?:;\"'*=_")
        for ((idx, r) in rows.withIndex()) {
            val row = newRow()
            for (ch in r) row.addView(key(ch.toString(), 1f) { onSymbol(ch.toString()) })
            if (idx == 2) row.addView(key("⌫", 1.5f, special = true, repeat = true) { onBackspace() })
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("ABC", 1.6f, special = true) { panel = Panel.LETTERS; refresh() })
        bottom.addView(key(",", 1f) { onSymbol(",") })
        bottom.addView(key("space", 4f) { onSpace() })
        bottom.addView(key(".", 1f) { onSymbol(".") })
        bottom.addView(key("↵", 1.6f, special = true) { onEnter() })
        root.addView(bottom)
    }

    private fun emojiPanel(root: LinearLayout) {
        for (chunk in emojis.chunked(6)) {
            val row = newRow()
            for (e in chunk) row.addView(key(e, 1f) { currentInputConnection?.commitText(e, 1) })
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("ABC", 2f, special = true) { panel = Panel.LETTERS; refresh() })
        bottom.addView(key("space", 5f) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(key("⌫", 2f, special = true, repeat = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(bottom)
    }

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, rowHeight())
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(t.accent)
        textSize = 18f
        gravity = Gravity.CENTER
        setPadding(dp(14), 0, dp(14), 0)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )
    }

    private fun key(
        text: String,
        weight: Float,
        special: Boolean = false,
        repeat: Boolean = false,
        onClick: () -> Unit
    ): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(if (special) t.special else t.key)
        }
        val v = TextView(this).apply {
            this.text = text
            setTextColor(t.text)
            textSize = 19f
            gravity = Gravity.CENTER
            background = bg
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            layoutParams = lp
        }
        if (repeat) {
            var repeater: Runnable? = null
            v.setOnTouchListener { view, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        feedback(view)
                        onClick()
                        val r = object : Runnable {
                            override fun run() {
                                feedback(view)
                                onClick()
                                handler.postDelayed(this, 55)
                            }
                        }
                        repeater = r
                        handler.postDelayed(r, 400)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        repeater?.let { handler.removeCallbacks(it) }
                        repeater = null
                    }
                }
                true
            }
        } else {
            v.setOnClickListener { feedback(it); onClick() }
        }
        return v
    }

    @Suppress("DEPRECATION")
    private fun feedback(v: View) {
        if (prefs.getBoolean("vibrate", true)) {
            v.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
        if (prefs.getBoolean("sound", false)) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
    }

    // ---------- Input logic ----------

    private fun onLetter(ch: Char) {
        val c = if (shift) ch.uppercaseChar() else ch
        val wasShift = shift
        shift = false
        if (sinhalaMode) {
            buffer.append(c)
            currentInputConnection?.setComposingText(Transliterator.convert(buffer.toString()), 1)
            if (wasShift) refresh() else updateSuggestions()
        } else {
            currentInputConnection?.commitText(c.toString(), 1)
            if (wasShift) refresh()
        }
    }

    private fun onBackspace() {
        if (buffer.isNotEmpty()) {
            buffer.deleteCharAt(buffer.length - 1)
            if (buffer.isEmpty()) {
                currentInputConnection?.commitText("", 1)
            } else {
                currentInputConnection?.setComposingText(Transliterator.convert(buffer.toString()), 1)
            }
            updateSuggestions()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun onSpace() {
        commitComposing()
        currentInputConnection?.commitText(" ", 1)
    }

    private fun onSymbol(s: String) {
        commitComposing()
        currentInputConnection?.commitText(s, 1)
    }

    private fun onEnter() {
        commitComposing()
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
            ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun pick(word: String) {
        currentInputConnection?.commitText("$word ", 1)
        learn(word)
        buffer.clear()
        updateSuggestions()
    }

    private fun commitComposing() {
        if (buffer.isNotEmpty()) {
            val word = Transliterator.convert(buffer.toString())
            currentInputConnection?.commitText(word, 1)
            learn(word)
            buffer.clear()
            updateSuggestions()
        }
    }

    private fun learn(word: String) {
        if (word.length < 2 || word[0].code !in 0x0D80..0x0DFF) return
        val n = (learnedCache[word] ?: 0) + 1
        learnedCache[word] = n
        learned.edit().putInt(word, n).apply()
    }
}
