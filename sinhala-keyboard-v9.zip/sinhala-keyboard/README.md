# Sinha Keys (Android)

Singlish to Sinhala typing, learning word suggestions, 15 themes, 8 animated keyboard backgrounds,
full emoji and symbol panels, fast typing options. All app screens are in English.

## Build without a computer (GitHub Actions)
1. Put the zip in a GitHub repo (only ONE zip in the repo, delete older ones).
2. The workflow builds app-debug.apk. Download it from Actions > the latest run > Artifacts.
3. Builds use a fixed debug key (app/debug.keystore), so a newer APK installs over an older one.
   (The very first switch from an older build needs one uninstall.)

## Before the Play Store
- Change `applicationId` in app/build.gradle.kts.
- Create your own release signing key (do not use the debug key) and build a signed AAB.
- Add a Privacy Policy: nothing typed is collected or sent anywhere. The app has the INTERNET permission only to load news headlines (RSS) and uses notifications for news alerts. Status Saver reads only the WhatsApp folder you pick.
- Add screenshots and the 512px icon.
