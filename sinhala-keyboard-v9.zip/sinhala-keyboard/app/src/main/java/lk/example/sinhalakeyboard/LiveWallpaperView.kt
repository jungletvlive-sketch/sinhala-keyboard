package lk.example.sinhalakeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Animated keyboard background. type: 0 none, 1 aurora, 2 stars, 3 bubbles, 4 rain,
 * 5 fireflies, 6 ocean waves, 7 snow, 8 gradient flow.
 */
class LiveWallpaperView(context: Context) : View(context) {

    private class Particle(var x: Float, var y: Float, val size: Float, val speed: Float, val phase: Float)

    private var type = 0
    private var theme: KbTheme = Themes.all[0]
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var bgShader: Shader? = null
    private var particles: Array<Particle> = emptyArray()
    private var lastFrame = 0L
    private val rnd = java.util.Random(42)
    private val d = context.resources.displayMetrics.density

    fun configure(type: Int, theme: KbTheme) {
        this.type = type
        this.theme = theme
        particles = emptyArray()
        bgShader = null
        lastFrame = 0L
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgShader = null
        particles = emptyArray()
    }

    private fun particleCount(): Int = when (type) {
        2 -> 38
        3 -> 16
        4 -> 40
        5 -> 20
        7 -> 36
        9 -> 30
        else -> 0
    }

    private fun newParticle(w: Float, h: Float): Particle {
        val r = rnd
        val x = r.nextFloat() * w
        val y = r.nextFloat() * h
        val ph = r.nextFloat() * 6.28f
        return when (type) {
            2 -> Particle(x, y, (0.6f + r.nextFloat() * 1.4f) * d, 0.8f + r.nextFloat() * 1.7f, ph)
            3 -> Particle(x, y, (6f + r.nextFloat() * 18f) * d, (14f + r.nextFloat() * 30f) * d, ph)
            4 -> Particle(x, y, (8f + r.nextFloat() * 14f) * d, (300f + r.nextFloat() * 300f) * d, ph)
            5 -> Particle(x, y, (1.5f + r.nextFloat() * 2f) * d, 1f, ph)
            else -> Particle(x, y, (1.5f + r.nextFloat() * 3f) * d, (20f + r.nextFloat() * 40f) * d, ph)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.033f else (now - lastFrame).coerceIn(1L, 100L) / 1000f
        lastFrame = now
        val t = now / 1000f

        if (type >= 10) {
            drawPhoto(canvas, w, h)
            return
        }
        paint.style = Paint.Style.FILL
        if (type == 8) {
            val c1 = Color.HSVToColor(floatArrayOf((t * 12f) % 360f, 0.65f, 0.55f))
            val c2 = Color.HSVToColor(floatArrayOf((t * 12f + 70f) % 360f, 0.7f, 0.35f))
            paint.shader = LinearGradient(0f, 0f, w, h, c1, c2, Shader.TileMode.CLAMP)
        } else {
            if (bgShader == null) {
                bgShader = LinearGradient(0f, 0f, 0f, h, theme.bg1, theme.bg2, Shader.TileMode.CLAMP)
            }
            paint.shader = bgShader
        }
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        if (particles.isEmpty() && particleCount() > 0) {
            particles = Array(particleCount()) { newParticle(w, h) }
        }

        when (type) {
            1 -> aurora(canvas, w, h, t)
            2 -> stars(canvas, w, h, t)
            3 -> bubbles(canvas, w, h, t, dt)
            4 -> rain(canvas, w, h, dt)
            5 -> fireflies(canvas, w, h, t, dt)
            6 -> waves(canvas, w, h, t)
            7 -> snow(canvas, w, h, t, dt)
            9 -> skull(canvas, w, h, t, dt)
        }

        if (type != 0) postInvalidateDelayed(33)
    }

    private fun aurora(c: Canvas, w: Float, h: Float, t: Float) {
        val colors = intArrayOf(theme.accent, 0xFF7C4DFF.toInt(), 0xFF00E5A8.toInt())
        paint.style = Paint.Style.FILL
        for (i in 0 until 3) {
            path.reset()
            val base = h * (0.35f + 0.18f * i)
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w + 12f) {
                val y = base +
                    sin(x / w * 5.2f + t * (0.6f + i * 0.25f) + i * 2f) * h * 0.14f +
                    sin(x / w * 11f - t * 0.9f) * h * 0.04f
                path.lineTo(x, y)
                x += 12f
            }
            path.lineTo(w + 12f, h)
            path.close()
            paint.shader = LinearGradient(
                0f, base - h * 0.2f, 0f, h,
                Themes.alpha(colors[i], 0x70), Themes.alpha(colors[i], 0x00), Shader.TileMode.CLAMP
            )
            c.drawPath(path, paint)
        }
        paint.shader = null
    }

    private fun waves(c: Canvas, w: Float, h: Float, t: Float) {
        paint.style = Paint.Style.FILL
        for (i in 0 until 3) {
            path.reset()
            val base = h * (0.45f + 0.17f * i)
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w + 12f) {
                val y = base + sin(x / w * (4f + i) + t * (0.9f + i * 0.4f) + i * 1.7f) * h * 0.07f
                path.lineTo(x, y)
                x += 12f
            }
            path.lineTo(w + 12f, h)
            path.close()
            paint.color = Themes.alpha(if (i == 1) Color.WHITE else theme.accent, 0x28 + i * 0x14)
            c.drawPath(path, paint)
        }
    }

    private fun stars(c: Canvas, w: Float, h: Float, t: Float) {
        paint.style = Paint.Style.FILL
        for (p in particles) {
            val a = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * p.speed + p.phase))
            paint.color = Color.argb((a * 255f).toInt().coerceIn(0, 255), 255, 255, 255)
            c.drawCircle(p.x, p.y, p.size, paint)
        }
        val cyc = t % 7f
        if (cyc < 0.8f) {
            val k = cyc / 0.8f
            val x0 = w * 0.1f + w * 0.7f * k
            val y0 = h * 0.1f + h * 0.35f * k
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * d
            paint.color = Color.argb(((1f - k) * 255f).toInt().coerceIn(0, 255), 255, 255, 255)
            c.drawLine(x0, y0, x0 - 40f * d, y0 - 18f * d, paint)
            paint.style = Paint.Style.FILL
        }
    }

    private fun bubbles(c: Canvas, w: Float, h: Float, t: Float, dt: Float) {
        for (p in particles) {
            p.y -= p.speed * dt
            if (p.y < -p.size * 2f) {
                p.y = h + p.size
                p.x = rnd.nextFloat() * w
            }
            val x = p.x + sin(t * 0.8f + p.phase) * 10f * d
            paint.style = Paint.Style.FILL
            paint.color = Themes.alpha(theme.accent, 0x22)
            c.drawCircle(x, p.y, p.size, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.5f * d
            paint.color = Themes.alpha(theme.accent, 0xAA)
            c.drawCircle(x, p.y, p.size, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun rain(c: Canvas, w: Float, h: Float, dt: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * d
        paint.color = Themes.alpha(0xFFBBDEFB.toInt(), 0x90)
        for (p in particles) {
            p.y += p.speed * dt
            p.x -= p.speed * dt * 0.15f
            if (p.y > h + p.size) {
                p.y = -p.size
                p.x = rnd.nextFloat() * (w + 40f * d)
            }
            c.drawLine(p.x, p.y, p.x - p.size * 0.15f, p.y + p.size, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun fireflies(c: Canvas, w: Float, h: Float, t: Float, dt: Float) {
        paint.style = Paint.Style.FILL
        for (p in particles) {
            p.x += cos(t * 0.5f + p.phase) * 20f * d * dt
            p.y += sin(t * 0.4f + p.phase * 1.3f) * 15f * d * dt
            if (p.x < 0f) p.x = w
            if (p.x > w) p.x = 0f
            if (p.y < 0f) p.y = h
            if (p.y > h) p.y = 0f
            val a = 0.4f + 0.6f * (0.5f + 0.5f * sin(t * 1.5f + p.phase))
            paint.color = Themes.alpha(0xFFFFE066.toInt(), (a * 0x18).toInt())
            c.drawCircle(p.x, p.y, p.size * 4f, paint)
            paint.color = Themes.alpha(0xFFFFE066.toInt(), (a * 0x50).toInt())
            c.drawCircle(p.x, p.y, p.size * 2.2f, paint)
            paint.color = Themes.alpha(0xFFFFF59D.toInt(), (a * 255f).toInt().coerceIn(0, 255))
            c.drawCircle(p.x, p.y, p.size, paint)
        }
    }

    private fun snow(c: Canvas, w: Float, h: Float, t: Float, dt: Float) {
        paint.style = Paint.Style.FILL
        paint.color = Themes.alpha(Color.WHITE, 0xCC)
        for (p in particles) {
            p.y += p.speed * dt
            p.x += sin(t + p.phase) * 12f * d * dt
            if (p.y > h + p.size) {
                p.y = -p.size
                p.x = rnd.nextFloat() * w
            }
            c.drawCircle(p.x, p.y, p.size, paint)
        }
    }

    private val skullPath: Path by lazy {
        val a = Path()
        a.addOval(RectF(12f, 4f, 88f, 76f), Path.Direction.CW)
        val b = Path()
        b.addRoundRect(RectF(28f, 62f, 72f, 98f), 10f, 10f, Path.Direction.CW)
        a.op(b, Path.Op.UNION)
        a
    }
    private val tmpRect = RectF()

    /** A glowing skull with pulsing colour-changing eyes and rising embers. */
    private fun skull(c: Canvas, w: Float, h: Float, t: Float, dt: Float) {
        paint.style = Paint.Style.FILL
        for (p in particles) {
            p.y -= p.speed * dt
            p.x += sin(t + p.phase) * 10f * d * dt
            if (p.y < -p.size) {
                p.y = h + p.size
                p.x = rnd.nextFloat() * w
            }
            val a = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * 2f + p.phase))
            paint.color = Themes.alpha(0xFFFF6A3D.toInt(), (a * 0x40).toInt())
            c.drawCircle(p.x, p.y, p.size * 3f, paint)
            paint.color = Themes.alpha(0xFFFFB347.toInt(), (a * 255f).toInt().coerceIn(0, 255))
            c.drawCircle(p.x, p.y, p.size * 0.9f, paint)
        }
        val s = h * 0.8f / 100f
        val pulse = 0.5f + 0.5f * sin(t * 1.6f)
        val eye = Color.HSVToColor(floatArrayOf((t * 40f) % 360f, 0.9f, 1f))
        c.save()
        c.translate(w / 2f - 50f * s, h / 2f - 50f * s)
        c.scale(s, s)
        // aura
        paint.color = Themes.alpha(eye, (0x14 + 0x18 * pulse).toInt())
        c.drawCircle(50f, 48f, 62f, paint)
        paint.color = Themes.alpha(eye, (0x10 + 0x14 * pulse).toInt())
        c.drawCircle(50f, 48f, 48f, paint)
        // bone
        paint.color = Themes.alpha(0xFFFFFFFF.toInt(), 0x26)
        c.drawPath(skullPath, paint)
        // glowing outline
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        val widths = floatArrayOf(6f, 3.5f, 1.6f)
        val alphas = intArrayOf(40, 90, 255)
        for (i in widths.indices) {
            paint.strokeWidth = widths[i]
            paint.color = Themes.alpha(theme.accent, alphas[i])
            c.drawPath(skullPath, paint)
        }
        paint.style = Paint.Style.FILL
        // eye sockets
        paint.color = 0xFF0A0710.toInt()
        tmpRect.set(23f, 33f, 45f, 59f); c.drawOval(tmpRect, paint)
        tmpRect.set(55f, 33f, 77f, 59f); c.drawOval(tmpRect, paint)
        // glowing eyes
        val r = 4.5f + 1.5f * pulse
        for (ex in floatArrayOf(34f, 66f)) {
            paint.color = Themes.alpha(eye, 0x30); c.drawCircle(ex, 47f, r * 2.6f, paint)
            paint.color = Themes.alpha(eye, 0x80); c.drawCircle(ex, 47f, r * 1.6f, paint)
            paint.color = Themes.alpha(0xFFFFFFFF.toInt(), 0xF0); c.drawCircle(ex, 47f, r * 0.7f, paint)
        }
        // nose
        path.reset()
        path.moveTo(50f, 60f); path.lineTo(44f, 72f); path.lineTo(56f, 72f); path.close()
        paint.color = 0xFF0A0710.toInt()
        c.drawPath(path, paint)
        // teeth
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.4f
        paint.color = Themes.alpha(theme.accent, 0xB0)
        c.drawLine(34f, 84f, 66f, 84f, paint)
        for (x in floatArrayOf(40f, 50f, 60f)) c.drawLine(x, 84f, x, 96f, paint)
        c.restore()
        paint.style = Paint.Style.FILL
    }

    /** Picture wallpapers: the photo fills the keyboard with a dark layer on top so the keys stay readable. */
    private fun drawPhoto(c: Canvas, w: Float, h: Float) {
        var bmp = photoCache.get(type)
        if (bmp == null) {
            bmp = try {
                context.assets.open("wallpapers/w${type - 10}.jpg").use { BitmapFactory.decodeStream(it) }
            } catch (e: Exception) {
                null
            }
            if (bmp != null) photoCache.put(type, bmp)
        }
        if (bmp == null) {
            c.drawColor(theme.bg1)
            return
        }
        val scale = max(w / bmp.width, h / bmp.height)
        val sw = bmp.width * scale
        val sh = bmp.height * scale
        tmpRect.set((w - sw) / 2f, (h - sh) / 2f, (w + sw) / 2f, (h + sh) / 2f)
        paint.isFilterBitmap = true
        paint.shader = null
        c.drawBitmap(bmp, null, tmpRect, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(0x78, 0, 0, 0)
        c.drawRect(0f, 0f, w, h, paint)
    }

    private companion object {
        val photoCache = android.util.LruCache<Int, Bitmap>(6)
    }
}
