package lk.example.sinhalakeyboard

/** Stylish text: Unicode "fonts" for English letters and decoration pairs. */
object Stylish {

    class Font(val name: String, val map: (Char) -> String)
    class Deco(val pre: String, val suf: String)

    private fun cp(x: Int): String = String(Character.toChars(x))

    /** Mathematical alphanumeric style: contiguous blocks with optional exceptions. */
    private fun block(upper: Int, lower: Int, digit: Int = -1, exc: Map<Char, Int> = emptyMap()): (Char) -> String = { c ->
        val e = exc[c]
        when {
            e != null -> cp(e)
            c in 'A'..'Z' -> cp(upper + (c - 'A'))
            c in 'a'..'z' -> cp(lower + (c - 'a'))
            c in '0'..'9' && digit >= 0 -> cp(digit + (c - '0'))
            else -> c.toString()
        }
    }

    /** Both cases map into one lowercase-style string (26 chars). */
    private fun letters(lower: String, upperToo: Boolean = true, digits: String? = null): (Char) -> String {
        val l = lower.codePoints().toArray()
        return { c ->
            when {
                c in 'a'..'z' -> cp(l[c - 'a'])
                c in 'A'..'Z' -> if (upperToo) cp(l[c - 'A']) else c.toString()
                c in '0'..'9' && digits != null -> digits[c - '0'].toString()
                else -> c.toString()
            }
        }
    }

    private fun mark(m: Char): (Char) -> String = { c ->
        if (c.code in 33..126 && c != ' ') c.toString() + m else c.toString()
    }

    val fonts: List<Font> = listOf(
        Font("Bold", block(0x1D400, 0x1D41A, 0x1D7CE)),
        Font("Italic", block(0x1D434, 0x1D44E, -1, mapOf('h' to 0x210E))),
        Font("Bold Italic", block(0x1D468, 0x1D482)),
        Font("Script", block(0x1D49C, 0x1D4B6, -1, mapOf(
            'B' to 0x212C, 'E' to 0x2130, 'F' to 0x2131, 'H' to 0x210B, 'I' to 0x2110, 'L' to 0x2112,
            'M' to 0x2133, 'R' to 0x211B, 'e' to 0x212F, 'g' to 0x210A, 'o' to 0x2134))),
        Font("Bold Script", block(0x1D4D0, 0x1D4EA)),
        Font("Fraktur", block(0x1D504, 0x1D51E, -1, mapOf(
            'C' to 0x212D, 'H' to 0x210C, 'I' to 0x2111, 'R' to 0x211C, 'Z' to 0x2128))),
        Font("Bold Fraktur", block(0x1D56C, 0x1D586)),
        Font("Double Struck", block(0x1D538, 0x1D552, 0x1D7D8, mapOf(
            'C' to 0x2102, 'H' to 0x210D, 'N' to 0x2115, 'P' to 0x2119, 'Q' to 0x211A, 'R' to 0x211D, 'Z' to 0x2124))),
        Font("Sans", block(0x1D5A0, 0x1D5BA, 0x1D7E2)),
        Font("Sans Bold", block(0x1D5D4, 0x1D5EE, 0x1D7EC)),
        Font("Sans Italic", block(0x1D608, 0x1D622)),
        Font("Sans Bold Italic", block(0x1D63C, 0x1D656)),
        Font("Monospace", block(0x1D670, 0x1D68A, 0x1D7F6)),
        Font("Circled", { c ->
            when {
                c in 'A'..'Z' -> cp(0x24B6 + (c - 'A'))
                c in 'a'..'z' -> cp(0x24D0 + (c - 'a'))
                c in '1'..'9' -> cp(0x2460 + (c - '1'))
                c == '0' -> cp(0x24EA)
                else -> c.toString()
            }
        }),
        Font("Black Circled", { c ->
            when {
                c in 'A'..'Z' -> cp(0x1F150 + (c - 'A'))
                c in 'a'..'z' -> cp(0x1F150 + (c - 'a'))
                else -> c.toString()
            }
        }),
        Font("Squared", { c ->
            when {
                c in 'A'..'Z' -> cp(0x1F130 + (c - 'A'))
                c in 'a'..'z' -> cp(0x1F130 + (c - 'a'))
                else -> c.toString()
            }
        }),
        Font("Black Squared", { c ->
            when {
                c in 'A'..'Z' -> cp(0x1F170 + (c - 'A'))
                c in 'a'..'z' -> cp(0x1F170 + (c - 'a'))
                else -> c.toString()
            }
        }),
        Font("Parenthesized", { c ->
            when {
                c in 'A'..'Z' -> cp(0x249C + (c - 'A'))
                c in 'a'..'z' -> cp(0x249C + (c - 'a'))
                else -> c.toString()
            }
        }),
        Font("Fullwidth", { c ->
            when {
                c in '!'..'~' -> cp(0xFF01 + (c - '!'))
                else -> c.toString()
            }
        }),
        Font("Small Caps", letters("ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ", upperToo = true)),
        Font("Tiny", letters("ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖᑫʳˢᵗᵘᵛʷˣʸᶻ", upperToo = true, digits = "⁰¹²³⁴⁵⁶⁷⁸⁹")),
        Font("Strikethrough", mark('̶')),
        Font("Underline", mark('̲')),
        Font("Double Underline", mark('̳')),
        Font("Overline", mark('̅')),
        Font("Slash", mark('̸')),
        Font("Wavy", mark('͠')),
        Font("Dotted", mark('̣'))
    )

    val decos: List<Deco> = listOf(
        Deco("✨ ", " ✨"), Deco("⋆˚ ", " ˚⋆"), Deco("★ ", " ★"), Deco("☆ ", " ☆"), Deco("♡ ", " ♡"),
        Deco("•°• ", " •°•"), Deco("꧁ ", " ꧂"), Deco("【", "】"), Deco("『", "』"), Deco("「", "」"),
        Deco("《", "》"), Deco("❝ ", " ❞"), Deco("🔥 ", " 🔥"), Deco("💫 ", " 💫"), Deco("🌸 ", " 🌸"),
        Deco("⚡ ", " ⚡"), Deco("👑 ", " 👑"), Deco("🦋 ", " 🦋"), Deco("✿ ", " ✿"), Deco("❀ ", " ❀"),
        Deco("·.·★ ", " ★·.·"), Deco("▁▂▃ ", " ▃▂▁"), Deco("〖", "〗"), Deco("『✦ ", " ✦』"),
        Deco("☾ ", " ☽"), Deco("♛ ", " ♛"), Deco("✦ ", " ✦"), Deco("➳ ", " ➳"), Deco("🌙 ", " 🌙"),
        Deco("💎 ", " 💎"), Deco("🌹 ", " 🌹"), Deco("🦁 ", " 🦁"), Deco("🇱🇰 ", " 🇱🇰"), Deco("»» ", " ««"),
        Deco("♪ ", " ♪"), Deco("─── ", " ───")
    )

    fun apply(font: Int, text: String): String {
        if (font < 0 || font >= fonts.size) return text
        val f = fonts[font].map
        val sb = StringBuilder()
        for (ch in text) sb.append(f(ch))
        return sb.toString()
    }

    fun decorate(d: Int, text: String): String {
        if (d < 0 || d >= decos.size) return text
        return decos[d].pre + text + decos[d].suf
    }
}
