package lk.example.sinhalakeyboard

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * A chat with an AI assistant. It talks to the Anthropic API with the key you paste in.
 * The key and the chat stay on this phone; only what you send in this chat goes to the AI service.
 */
class AiActivity : Activity() {

    private val history = ArrayList<Pair<String, String>>() // role, text
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var keyCard: LinearLayout
    private lateinit var input: EditText
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "AI Assistant")
        scroll = c.parent as ScrollView
        val root = scroll.parent as LinearLayout
        chat = c

        // key card
        keyCard = Ui.card(this)
        keyCard.addView(Ui.label(this, "Connect your AI key"))
        keyCard.addView(
            Ui.body(
                this,
                "The assistant uses your own Anthropic API key (create one at console.anthropic.com, API keys). " +
                    "The key is saved only on this phone.",
                13f
            )
        )
        val keyField = Ui.inputField(this, "sk-ant-...")
        keyField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        Ui.add(keyCard, keyField, 10)
        Ui.add(keyCard, Ui.button(this, "Save key") {
            val k = keyField.text.toString().trim()
            if (k.isNotEmpty()) {
                Prefs.of(this).edit().putString(Prefs.AI_KEY, k).apply()
                keyField.setText("")
                keyCard.visibility = View.GONE
                bubble("Key saved. Ask me anything.", false)
            }
        }, 10)
        Ui.add(c, keyCard, 4)
        if (!getKey().isNullOrEmpty()) keyCard.visibility = View.GONE

        val change = Ui.body(this, "Change API key", 12f)
        change.setOnClickListener { keyCard.visibility = if (keyCard.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        Ui.add(c, change, 6)

        bubble("Hi! I am the Sinha Keys assistant. Ask me anything in Sinhala, Singlish or English. I can help with typing, messages, translating and general questions.", false)

        // quick ideas
        val chips = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (q in listOf("How do I type ට, ඩ and ණ?", "Write a polite good morning message", "Translate this to Sinhala: Thank you very much")) {
            val chip = TextView(this).apply {
                text = q
                textSize = 14f
                setTextColor(Ui.TEXT)
                background = Ui.pill(Ui.CHIP)
                setPadding(Ui.dp(context, 14), Ui.dp(context, 8), Ui.dp(context, 14), Ui.dp(context, 8))
                setOnClickListener { chips.visibility = View.GONE; send(q) }
            }
            Ui.add(chips, chip, 6)
        }
        Ui.add(c, chips, 8)

        // input bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(Ui.dp(context, 10), Ui.dp(context, 8), Ui.dp(context, 10), Ui.dp(context, 8))
        }
        input = Ui.inputField(this, "Message")
        input.maxLines = 4
        bar.addView(input, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        val sendBtn = Ui.button(this, "Send") {
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) {
                input.setText("")
                chips.visibility = View.GONE
                send(q)
            }
        }
        val lp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        lp.leftMargin = Ui.dp(this, 8)
        bar.addView(sendBtn, lp)
        root.addView(bar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
    }

    private fun getKey(): String? = Prefs.of(this).getString(Prefs.AI_KEY, null)

    private fun bubble(text: String, user: Boolean): TextView {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Ui.TEXT)
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.15f)
            maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
            setPadding(Ui.dp(context, 14), Ui.dp(context, 10), Ui.dp(context, 14), Ui.dp(context, 10))
            background = GradientDrawable().apply {
                cornerRadius = Ui.dp(context, 16).toFloat()
                setColor(if (user) 0xFF5B4BD6.toInt() else Ui.CARD)
            }
        }
        val lp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        lp.topMargin = Ui.dp(this, 8)
        lp.gravity = if (user) Gravity.END else Gravity.START
        chat.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun send(question: String) {
        val key = getKey()
        if (key.isNullOrEmpty()) {
            keyCard.visibility = View.VISIBLE
            bubble("Please save your AI key first (the card at the top).", false)
            return
        }
        if (busy) return
        busy = true
        bubble(question, true)
        val answer = bubble("...", false)
        history.add(Pair("user", question))
        val snapshot = ArrayList(history.takeLast(16))
        Thread {
            val reply = try {
                ask(key, snapshot)
            } catch (e: Exception) {
                Pair("Could not reach the AI. Check your internet connection and try again.", false)
            }
            runOnUiThread {
                busy = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                answer.text = reply.first
                if (reply.second) history.add(Pair("assistant", reply.first)) else history.removeAt(history.size - 1)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }.start()
    }

    /** Returns the answer and whether it was a real answer (not an error). */
    private fun ask(key: String, msgs: List<Pair<String, String>>): Pair<String, Boolean> {
        val arr = JSONArray()
        for ((role, text) in msgs) arr.put(JSONObject().put("role", role).put("content", text))
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 1024)
            .put("system", SYSTEM)
            .put("messages", arr)
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                return if (code == 401) Pair("The API key is not valid. Tap \"Change API key\" and paste it again.", false)
                else Pair("The AI service returned an error ($code). " + errorMessage(text), false)
            }
            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            val out = sb.toString().trim()
            return if (out.isEmpty()) Pair("The AI sent an empty answer. Please try again.", false) else Pair(out, true)
        } finally {
            conn.disconnect()
        }
    }

    private fun errorMessage(text: String): String = try {
        JSONObject(text).getJSONObject("error").optString("message")
    } catch (e: Exception) {
        ""
    }

    private companion object {
        const val SYSTEM =
            "You are the AI Assistant inside Sinha Keys, an Android Sinhala keyboard app made by Shashendra Nirvan. " +
                "People often write Sinhala with English letters (Singlish) or in Sinhala script. " +
                "Answer in Sinhala script unless the person writes in English, then answer in English. " +
                "Keep answers short, friendly and clear. You can help with writing messages, translating, " +
                "general questions and using the keyboard. Keyboard typing rules (Singlish): small letters are soft sounds " +
                "(t ත, d ද, n න, l ල, s ස, sh ශ), capital letters are heavy sounds (T ට, D ඩ, N ණ, L ළ, S ෂ), " +
                "x gives ං, H gives ඃ, zg ඟ, zd ඬ, zq ඳ, B ඹ, kra ක්‍ර, kya ක්‍ය, aa ආ, ae ඇ, ii ඊ, uu ඌ. " +
                "The app also has themes, live wallpapers, RGB lights, emoji and symbol panels, a clipboard with pins, " +
                "a WhatsApp Status Saver and news alerts."
    }
}
