package lk.example.sinhalakeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout

class MainActivity : Activity() {

    private var setupCard: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Sinhala Keyboard", back = false)

        c.addView(Ui.inputField(this, "Test your keyboard"))

        val card = Ui.card(this)
        card.addView(Ui.label(this, "Turn on the keyboard"))
        card.addView(Ui.body(this, "1. Enable it in system settings, then 2. choose it as your active keyboard.", 13f))
        Ui.add(card, Ui.button(this, "1. Enable keyboard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        Ui.add(card, Ui.button(this, "2. Select keyboard", 0xFF4DD0E1.toInt()) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        setupCard = card
        Ui.add(c, card, 14)

        fun open(cls: Class<*>, kind: String? = null) {
            val i = Intent(this, cls)
            if (kind != null) i.putExtra("kind", kind)
            startActivity(i)
        }

        val tiles = listOf(
            Ui.tile(this, "🎨", "Themes", 0xFF7C6CFF.toInt()) { open(ThemesActivity::class.java) },
            Ui.tile(this, "🌌", "Live Wallpapers", 0xFF00C2FF.toInt()) { open(WallpapersActivity::class.java) },
            Ui.tile(this, "😀", "Emojis", 0xFFFFC857.toInt()) { open(GlyphBrowserActivity::class.java, "emoji") },
            Ui.tile(this, "✨", "Epic Symbols", 0xFFFF6FB5.toInt()) { open(GlyphBrowserActivity::class.java, "symbols") },
            Ui.tile(this, "⚡", "Fast Typing", 0xFFFF9800.toInt()) { open(FastTypingActivity::class.java) },
            Ui.tile(this, "📰", "News Alerts", 0xFFEF5350.toInt()) { open(NewsActivity::class.java) },
            Ui.tile(this, "💾", "Status Saver", 0xFF25D366.toInt()) { open(StatusActivity::class.java) },
            Ui.tile(this, "⚙", "Settings", 0xFF8C9EFF.toInt()) { open(SettingsActivity::class.java) },
            Ui.tile(this, "📖", "Dictionary", 0xFFB388FF.toInt()) { open(DictionaryActivity::class.java) },
            Ui.tile(this, "❓", "Help", 0xFFFFA726.toInt()) { open(HelpActivity::class.java) },
            Ui.tile(this, "ℹ", "About", 0xFF66BB6A.toInt()) { showAbout() }
        )
        Ui.add(c, Ui.grid(this, tiles, 3, 4), 8)
    }

    override fun onResume() {
        super.onResume()
        setupCard?.visibility = if (isKeyboardEnabled()) View.GONE else View.VISIBLE
    }

    private fun isKeyboardEnabled(): Boolean {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("Sinhala Keyboard 1.4")
            .setMessage(
                "Type Sinhala using English letters (Singlish).\n\n" +
                    "• Word suggestions that learn from you\n" +
                    "• 15 themes and 8 live wallpapers\n" +
                    "• Full emoji and symbol panels\n" +
                    "• Fast typing mode\n" +
                    "• News alerts and WhatsApp Status Saver\n\n" +
                    "Nothing you type leaves your phone. The internet is used only to load news headlines."
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
