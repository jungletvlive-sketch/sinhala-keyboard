package lk.example.sinhalakeyboard

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class ThemesActivity : Activity() {

    private lateinit var preview: KeyboardPreview
    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Themes")
        c.addView(Ui.inputField(this, "Test your keyboard"))
        preview = KeyboardPreview(this)
        Ui.add(c, preview, 12)
        preview.layoutParams = (preview.layoutParams as LinearLayout.LayoutParams).apply {
            height = Ui.dp(this@ThemesActivity, 150)
        }
        Ui.add(c, Ui.body(this, "Tap a theme to apply it. It shows up the next time the keyboard opens.", 13f), 10)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.add(c, container, 6)
        render()
    }

    private fun render() {
        val prefs = Prefs.of(this)
        val sel = prefs.getInt(Prefs.THEME, 0).coerceIn(0, Themes.all.size - 1)
        val wall = prefs.getInt(Prefs.WALLPAPER, 0).coerceIn(0, Wallpapers.names.size - 1)
        preview.set(Themes.all[sel], wall)
        container.removeAllViews()
        val cards = Themes.all.mapIndexed { i, th -> themeCard(i, th, i == sel) }
        container.addView(Ui.grid(this, cards, 2, 6))
    }

    private fun themeCard(index: Int, th: KbTheme, selected: Boolean): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(this@ThemesActivity, 6)
            setPadding(p, p, p, p)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = Ui.dp(this@ThemesActivity, 16).toFloat()
                setColor(if (selected) Ui.alpha(th.accent, 0x33) else Ui.CARD)
                setStroke(Ui.dp(this@ThemesActivity, 2), if (selected) th.accent else 0x00000000)
            }
        }
        val p = KeyboardPreview(this)
        p.set(th, 0)
        col.addView(p, LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 96)))
        col.addView(TextView(this).apply {
            text = if (selected) th.name + "  ✓" else th.name
            textSize = 14f
            setTextColor(Ui.TEXT)
            gravity = Gravity.CENTER
            setPadding(0, Ui.dp(this@ThemesActivity, 8), 0, Ui.dp(this@ThemesActivity, 4))
        })
        col.setOnClickListener {
            Prefs.of(this).edit().putInt(Prefs.THEME, index).apply()
            render()
        }
        return col
    }
}
