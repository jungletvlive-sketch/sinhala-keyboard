package lk.example.sinhalakeyboard

import android.app.Activity
import android.os.Bundle

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Settings")
        c.addView(Ui.inputField(this, "Test your keyboard"))

        Ui.add(c, Ui.heading(this, "FEEDBACK"), 6)
        Ui.add(c, Ui.switchRow(this, "Vibrate on keypress", "A short buzz every time you tap a key", Prefs.VIBRATE, true), 6)
        Ui.add(c, Ui.switchRow(this, "Key click sound", "Plays the system click sound", Prefs.SOUND, false), 8)

        Ui.add(c, Ui.heading(this, "LAYOUT"), 10)
        Ui.add(c, Ui.choiceRow(this, "Key height", listOf("Small", "Medium", "Large"), Prefs.HEIGHT, 1), 6)

        Ui.add(c, Ui.heading(this, "SUGGESTIONS"), 10)
        Ui.add(c, Ui.switchRow(this, "Word suggestions", "Show Sinhala words while you type", Prefs.SUGGEST, true), 6)
        Ui.add(c, Ui.switchRow(this, "Learn new words", "Remember words you use so they appear first", Prefs.LEARN, true), 8)
        Ui.add(c, Ui.switchRow(this, "Smart spelling", "Fix t/d/n/l and nd/ng spellings using known words (hondai → හොඳයි)", Prefs.SMART, true), 8)

        Ui.add(c, Ui.body(this, "Changes apply the next time the keyboard opens.", 13f), 14)
    }
}
