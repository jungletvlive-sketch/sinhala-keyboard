package lk.example.sinhalakeyboard

/**
 * Helakuru-style Singlish (phonetic) typing.
 *
 * Plain letters are the soft sounds: t ත, d ද, n න, l ල, s ස, sh ශ.
 * Capital letters are the heavy (retroflex) sounds: T ට, D ඩ, N ණ, L ළ, S ෂ.
 * An extra h makes the aspirated letters: kh ඛ, gh ඝ, chh ඡ, thh ථ, dhh ධ, ph ඵ, bh භ, Th ඨ, Dh ඪ.
 * Vowels: a අ, aa ආ, ae or A ඇ, aae or Aa ඈ, i ඉ, ii ඊ, u උ, uu ඌ, e එ, ee ඒ, o ඔ, oo ඕ, ai ඓ, au ඖ, R ඍ.
 * Others: x ං, H ඃ, B ඹ, zg ඟ, zj ඦ, zd ඬ, zq ඳ.
 * A consonant with no vowel gets a hal (්). "kra" and "kya" make ක්‍ර and ක්‍ය.
 */
object Transliterator {

    private const val HAL = "්"
    private const val ZWJ = "‍"

    // Capital letters that mean something on their own. Every other capital is read as lower case.
    private const val KEEP_UPPER = "ARTDNLSBHC"

    private val consonants: Map<String, String> = mapOf(
        "chh" to "ඡ", "thh" to "ථ", "dhh" to "ධ", "zdh" to "ඳ",
        "kh" to "ඛ", "gh" to "ඝ", "ch" to "ච", "jh" to "ඣ", "th" to "ත", "dh" to "ද",
        "ph" to "ඵ", "bh" to "භ", "Th" to "ඨ", "Dh" to "ඪ", "sh" to "ශ", "Sh" to "ෂ", "Ch" to "ඡ",
        "zk" to "ඞ", "zg" to "ඟ", "zj" to "ඦ", "zd" to "ඬ", "zq" to "ඳ", "zh" to "ඥ",
        "k" to "ක", "g" to "ග", "c" to "ච", "C" to "ඡ", "j" to "ජ", "T" to "ට", "D" to "ඩ", "N" to "ණ",
        "t" to "ත", "d" to "ද", "q" to "ද", "n" to "න", "p" to "ප", "b" to "බ", "B" to "ඹ", "m" to "ම",
        "y" to "ය", "r" to "ර", "l" to "ල", "L" to "ළ", "v" to "ව", "w" to "ව", "s" to "ස", "S" to "ෂ",
        "h" to "හ", "f" to "ෆ"
    )

    // Only used for alternative spellings (the "nd" in ඳ, "mb" in ඹ ...).
    private val prenasal: Map<String, String> = mapOf(
        "nd" to "ඳ", "mb" to "ඹ", "ng" to "ඟ", "nj" to "ඦ", "nD" to "ඬ"
    )

    // letter on its own, sign after a consonant
    private val vowels: Map<String, Pair<String, String>> = mapOf(
        "Ruu" to Pair("ඎ", "ෲ"), "Ru" to Pair("ඍ", "ෘ"), "R" to Pair("ඍ", "ෘ"),
        "aae" to Pair("ඈ", "ෑ"), "Aa" to Pair("ඈ", "ෑ"), "AA" to Pair("ඈ", "ෑ"), "A" to Pair("ඇ", "ැ"),
        "aa" to Pair("ආ", "ා"), "ae" to Pair("ඇ", "ැ"), "ai" to Pair("ඓ", "ෛ"),
        "au" to Pair("ඖ", "ෞ"), "ou" to Pair("ඖ", "ෞ"),
        "ii" to Pair("ඊ", "ී"), "uu" to Pair("ඌ", "ූ"), "ee" to Pair("ඒ", "ේ"), "oo" to Pair("ඕ", "ෝ"),
        "a" to Pair("අ", ""), "i" to Pair("ඉ", "ි"), "u" to Pair("උ", "ු"),
        "e" to Pair("එ", "ෙ"), "o" to Pair("ඔ", "ො")
    )

    private val SINGLE_S = Regex("S(?!h)")

    private fun <T> find(table: Map<String, T>, s: String, i: Int, maxLen: Int): Pair<T, Int>? {
        var len = minOf(maxLen, s.length - i)
        while (len >= 1) {
            val hit = table[s.substring(i, i + len)]
            if (hit != null) return Pair(hit, len)
            len--
        }
        return null
    }

    private fun fixCase(s: String): String {
        val sb = StringBuilder(s.length)
        for (idx in s.indices) {
            val ch = s[idx]
            if (ch.isUpperCase() && ch !in KEEP_UPPER) {
                sb.append(ch.lowercaseChar())
            } else if (ch == 'H' && idx > 0 && s[idx - 1] in "TDSC") {
                sb.append('h')
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** The normal conversion, exactly what you see while typing. */
    fun convert(input: String): String = convert(input, false, false, false)

    private fun convert(input: String, usePrenasal: Boolean, useAnusvara: Boolean, literalAi: Boolean): String {
        var s = fixCase(input)
        // A word ending in "ai" (lassanai, hondai) almost always means "yi".
        if (!literalAi && s.length >= 4 && s.endsWith("ai") && s[s.length - 3] !in "aeiouAR") {
            s = s.substring(0, s.length - 2) + "ayi"
        }
        val out = StringBuilder()
        var i = 0
        var halAfter: String? = null // the consonant just written with a hal, for blends like ක්‍ර
        while (i < s.length) {
            val prevHal = halAfter
            halAfter = null
            val ch = s[i]
            if (useAnusvara && ch == 'n' && i + 1 < s.length && s[i + 1] in "kgh") {
                out.append("ං")
                i++
                continue
            }
            if (s.startsWith("zn", i)) {
                out.append("ං")
                i += 2
                continue
            }
            if (ch == 'x') {
                out.append("ං")
                i++
                continue
            }
            if (ch == 'H') {
                out.append("ඃ")
                i++
                continue
            }
            var cons: Pair<String, Int>? = null
            if (usePrenasal) cons = find(prenasal, s, i, 2)
            if (cons == null) cons = find(consonants, s, i, 3)
            if (cons != null) {
                val c = cons.first
                i += cons.second
                val blend = prevHal != null &&
                    (((c == "ය" || c == "ර") && prevHal != "ර") || (c == "ෂ" && prevHal == "ක"))
                if (blend) out.append(ZWJ)
                val v = find(vowels, s, i, 3)
                if (v != null) {
                    out.append(c).append(v.first.second)
                    i += v.second
                } else {
                    out.append(c).append(HAL)
                    halAfter = c
                }
                continue
            }
            val v = find(vowels, s, i, 3)
            if (v != null) {
                out.append(v.first.first)
                i += v.second
                continue
            }
            out.append(ch)
            i++
        }
        return out.toString()
    }

    /** Other likely spellings of the same typing: ඳ ඟ ඹ forms, anusvara, and a real ඓ. */
    fun variants(input: String): List<String> {
        val base = convert(input)
        val out = LinkedHashSet<String>()
        for (lit in listOf(false, true)) {
            for (pre in listOf(false, true)) {
                for (an in listOf(false, true)) {
                    val r = convert(input, pre, an, lit)
                    if (r != base) out.add(r)
                }
            }
        }
        return out.toList()
    }

    private fun guessForms(input: String): List<String> {
        val forms = ArrayList<String>()
        forms.add(input)
        val last = input.lastOrNull()
        // people often leave out the long vowel at the end: denawa, mage
        if (last != null && last in "aeiou" && !(input.length >= 2 && input[input.length - 2] == last)) {
            forms.add(input + last)
        }
        for (f in ArrayList(forms)) {
            if (SINGLE_S.containsMatchIn(f)) forms.add(SINGLE_S.replace(f, "sh"))
        }
        return forms
    }

    /**
     * Wider list of possible readings, best guess first. The first item is always the normal conversion.
     * Used to look words up in the dictionary (mata -> මට, hondai -> හොඳයි, denawa -> දෙනවා).
     */
    fun guesses(input: String): List<String> {
        val out = LinkedHashSet<String>()
        out.add(convert(input))
        out.addAll(variants(input))
        for (form in guessForms(input)) {
            val pos = ArrayList<Int>()
            for (i in form.indices) {
                if (form[i] in "tdnlTDNL" && !(i + 1 < form.length && form[i + 1] == 'h')) pos.add(i)
                if (pos.size == 5) break
            }
            for (mask in 0 until (1 shl pos.size)) {
                val chars = form.toCharArray()
                for (b in pos.indices) {
                    if ((mask and (1 shl b)) != 0) {
                        val q = pos[b]
                        chars[q] = if (chars[q].isUpperCase()) chars[q].lowercaseChar() else chars[q].uppercaseChar()
                    }
                }
                val t = String(chars)
                for (pre in listOf(false, true)) {
                    for (an in listOf(false, true)) {
                        out.add(convert(t, pre, an, false))
                    }
                }
            }
        }
        return out.toList()
    }
}
