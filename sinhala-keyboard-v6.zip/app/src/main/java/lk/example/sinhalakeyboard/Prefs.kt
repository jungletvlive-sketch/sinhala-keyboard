package lk.example.sinhalakeyboard

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val THEME = "theme"
    const val WALLPAPER = "wallpaper"
    const val VIBRATE = "vibrate"
    const val SOUND = "sound"
    const val HEIGHT = "height"
    const val SUGGEST = "suggest"
    const val LEARN = "learn"
    const val NUMBER_ROW = "number_row"
    const val FAST = "fast"
    const val REPEAT = "repeat"
    const val DOUBLE_SPACE = "double_space"
    const val AUTO_CAP = "auto_cap"
    const val SINHALA = "sinhala_mode"
    const val SMART = "smart"
    const val NEWS_ALERTS = "news_alerts"
    const val NEWS_EVERY = "news_every"
    const val NEWS_SEEN = "news_seen"
    const val STATUS_TREE = "status_tree"

    fun of(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("kb", Context.MODE_PRIVATE)

    fun learned(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("learned", Context.MODE_PRIVATE)
}
