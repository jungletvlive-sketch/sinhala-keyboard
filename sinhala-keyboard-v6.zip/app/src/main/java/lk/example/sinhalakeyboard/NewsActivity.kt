package lk.example.sinhalakeyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class NewsActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "News Alerts")
        Ui.add(c, Ui.body(this, "Get a notification when new Sri Lankan headlines are published. The internet is used only on this screen and for the checks.", 14f), 6)

        Ui.add(c, Ui.switchRow(this, "News alerts", "Notify me about new headlines", Prefs.NEWS_ALERTS, false) { on ->
            if (on) askNotificationPermission()
            NewsJobService.apply(this)
        }, 14)
        Ui.add(c, Ui.choiceRow(this, "Check every", listOf("30 min", "1 hour", "3 hours"), Prefs.NEWS_EVERY, 1), 8)

        Ui.add(c, Ui.heading(this, "NEWS SOURCES"), 10)
        for (s in News.SOURCES) {
            Ui.add(c, Ui.switchRow(this, s.name, null, News.prefKey(s), s.defaultOn), 6)
        }

        Ui.add(c, Ui.heading(this, "LATEST HEADLINES"), 14)
        status = Ui.body(this, "", 14f)
        Ui.add(c, status, 4)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.add(c, list, 4)
        Ui.add(c, Ui.button(this, "Refresh") { load() }, 14)
        load()
    }

    override fun onPause() {
        super.onPause()
        NewsJobService.apply(this)
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    private fun load() {
        status.text = "Loading..."
        list.removeAllViews()
        Thread {
            val items = News.fetch(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                render(items)
            }
        }.start()
    }

    private fun render(items: List<NewsItem>) {
        list.removeAllViews()
        if (items.isEmpty()) {
            status.text = "No headlines. Check your internet connection or turn on a source."
            return
        }
        status.text = ""
        for (n in items.take(40)) {
            val card = Ui.card(this)
            card.addView(TextView(this).apply {
                text = n.title
                textSize = 16f
                setTextColor(Ui.TEXT)
            })
            val meta = listOf(n.source, News.ago(n.time)).filter { it.isNotEmpty() }.joinToString(" · ")
            card.addView(Ui.body(this, meta, 12f))
            card.setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)))
            }
            Ui.add(list, card, 8)
        }
    }
}
