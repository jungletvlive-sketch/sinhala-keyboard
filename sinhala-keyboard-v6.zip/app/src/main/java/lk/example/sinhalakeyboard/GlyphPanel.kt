package lk.example.sinhalakeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

class GlyphCategory(val icon: String, val name: String, val items: List<String>, val columns: Int)

/** Loads emoji / symbol lists from assets and keeps the "recent" list. */
object GlyphData {
    private val cache = HashMap<String, List<GlyphCategory>>()

    @Synchronized
    fun load(ctx: Context, file: String): List<GlyphCategory> {
        cache[file]?.let { return it }
        val result = ArrayList<GlyphCategory>()
        val paint = Paint()
        try {
            ctx.applicationContext.assets.open(file).bufferedReader().use { reader ->
                var icon = ""
                var name = ""
                var cols = 8
                var lineMode = false
                var items = ArrayList<String>()

                fun flush() {
                    if (name.isNotEmpty() && items.isNotEmpty()) {
                        result.add(GlyphCategory(icon, name, items.distinct(), cols))
                    }
                    items = ArrayList()
                }

                for (raw in reader.readLines()) {
                    if (raw.startsWith("## ")) {
                        flush()
                        val parts = raw.substring(3).split("|")
                        icon = parts[0]
                        name = parts.getOrElse(1) { "" }
                        cols = parts.getOrElse(2) { "8" }.toIntOrNull() ?: 8
                        lineMode = parts.getOrElse(3) { "space" } == "line"
                    } else if (raw.isNotBlank()) {
                        if (lineMode) {
                            items.add(raw.trim())
                        } else {
                            for (tok in raw.trim().split(" ")) {
                                if (tok.isNotEmpty() && paint.hasGlyph(tok)) items.add(tok)
                            }
                        }
                    }
                }
                flush()
            }
        } catch (e: Exception) {
            // missing asset: return what we have
        }
        cache[file] = result
        return result
    }

    private fun recentPrefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("recent", Context.MODE_PRIVATE)

    fun recents(ctx: Context, kind: String): List<String> {
        val s = recentPrefs(ctx).getString("recent_$kind", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }

    fun addRecent(ctx: Context, kind: String, glyph: String) {
        val list = ArrayList(recents(ctx, kind))
        list.remove(glyph)
        list.add(0, glyph)
        while (list.size > 32) list.removeAt(list.size - 1)
        recentPrefs(ctx).edit().putString("recent_$kind", list.joinToString("\n")).apply()
    }

    fun withRecents(ctx: Context, kind: String, file: String): List<GlyphCategory> {
        val base = load(ctx, file)
        val rec = recents(ctx, kind)
        if (rec.isEmpty()) return base
        return listOf(GlyphCategory("🕘", "Recent", rec, base.firstOrNull()?.columns ?: 8)) + base
    }
}

class GlyphAdapter(
    private val ctx: Context,
    val items: List<String>,
    private val color: Int,
    private val sizeSp: Float,
    private val cellPx: Int
) : BaseAdapter() {
    override fun getCount(): Int = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int): Long = position.toLong()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val tv = (convertView as? TextView) ?: TextView(ctx).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cellPx)
        }
        tv.text = items[position]
        tv.setTextColor(color)
        tv.textSize = sizeSp
        return tv
    }
}

/** Category tabs + scrolling grid. Used inside the keyboard and in the Emoji / Symbols screens. */
object GlyphPanel {
    fun build(
        ctx: Context,
        cats: List<GlyphCategory>,
        theme: KbTheme,
        gridHeightPx: Int,
        onPick: (String) -> Unit
    ): LinearLayout {
        val d = ctx.resources.displayMetrics.density
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        if (cats.isEmpty()) {
            root.addView(TextView(ctx).apply {
                text = "Nothing to show"
                setTextColor(theme.text)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, gridHeightPx))
            return root
        }

        val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val tabScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        }
        val grid = GridView(ctx).apply {
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            verticalSpacing = 0
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val tabs = ArrayList<TextView>()

        fun select(i: Int) {
            val cat = cats[i]
            grid.numColumns = cat.columns
            val size = if (cat.columns >= 8) 24f else if (cat.columns >= 4) 20f else 14f
            val cell = ((if (cat.columns >= 8) 44 else 40) * d).toInt()
            grid.adapter = GlyphAdapter(ctx, cat.items, theme.text, size, cell)
            grid.setSelection(0)
            for ((k, tv) in tabs.withIndex()) {
                tv.alpha = if (k == i) 1f else 0.5f
                tv.background = if (k == i) GradientDrawable().apply {
                    cornerRadius = 10f * d
                    setColor(Themes.alpha(theme.accent, 0x55))
                } else null
            }
        }

        for ((i, cat) in cats.withIndex()) {
            val tv = TextView(ctx).apply {
                text = cat.icon
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(theme.text)
                setPadding((12 * d).toInt(), 0, (12 * d).toInt(), 0)
                setOnClickListener { select(i) }
            }
            tabs.add(tv)
            tabRow.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (38 * d).toInt()))
        }

        grid.setOnItemClickListener { _, _, pos, _ ->
            val a = grid.adapter as? GlyphAdapter
            if (a != null && pos in a.items.indices) onPick(a.items[pos])
        }

        root.addView(tabScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (40 * d).toInt()))
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, gridHeightPx))
        select(0)
        return root
    }
}
