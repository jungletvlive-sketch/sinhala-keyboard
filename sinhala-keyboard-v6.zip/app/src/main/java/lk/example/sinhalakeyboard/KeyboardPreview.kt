package lk.example.sinhalakeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout

/** Small non-interactive preview of a theme (+ optional live wallpaper). */
class KeyboardPreview(context: Context) : FrameLayout(context) {

    private val wall = LiveWallpaperView(context)
    private val keys = KeysOverlay(context)

    init {
        val d = context.resources.displayMetrics.density
        addView(wall, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        addView(keys, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 12f * d)
            }
        }
        clipToOutline = true
    }

    fun set(theme: KbTheme, wallpaper: Int) {
        wall.configure(wallpaper, theme)
        keys.theme = theme
        keys.translucent = wallpaper != 0
        keys.invalidate()
    }

    private class KeysOverlay(context: Context) : View(context) {
        var theme: KbTheme = Themes.all[0]
        var translucent = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val d = context.resources.displayMetrics.density

        private val rows = listOf(
            floatArrayOf(1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f),
            floatArrayOf(0.5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 0.5f),
            floatArrayOf(1.5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1.5f),
            floatArrayOf(1.3f, 1.1f, 4f, 1.1f, 1.4f)
        )

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val pad = 8f * d
            val gap = 3f * d
            val stripH = 14f * d

            paint.color = Themes.alpha(theme.accent, 0xCC)
            for (i in 0 until 3) {
                val cw = 26f * d
                val x = pad + i * (cw + 8f * d)
                rect.set(x, pad * 0.8f, x + cw, pad * 0.8f + 5f * d)
                canvas.drawRoundRect(rect, 3f * d, 3f * d, paint)
            }

            val top = stripH + pad * 0.6f
            val rowH = (h - top - pad * 0.6f - gap * (rows.size - 1)) / rows.size
            var y = top
            for ((r, weights) in rows.withIndex()) {
                val total = weights.sum()
                val avail = w - pad * 2f - gap * (weights.size - 1)
                var x = pad
                for ((i, wt) in weights.withIndex()) {
                    val kw = avail * wt / total
                    val spacer = r == 1 && (i == 0 || i == weights.size - 1)
                    if (!spacer) {
                        val special = (r == 2 && (i == 0 || i == weights.size - 1)) ||
                            (r == 3 && i != 2)
                        paint.color = Themes.alpha(
                            if (special) theme.special else theme.key,
                            if (translucent) 0xC8 else 0xFF
                        )
                        rect.set(x, y, x + kw, y + rowH)
                        canvas.drawRoundRect(rect, 4f * d, 4f * d, paint)
                    }
                    x += kw + gap
                }
                y += rowH + gap
            }
        }
    }
}
