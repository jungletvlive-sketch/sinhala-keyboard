package lk.example.sinhalakeyboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast

/** Browse the emoji / symbol collections. Tap items to build text, then copy it. */
class GlyphBrowserActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra("kind") ?: "emoji"
        val isEmoji = kind == "emoji"
        val c = Ui.screen(this, if (isEmoji) "Emojis" else "Epic Symbols")

        val field = Ui.inputField(this, "Tap items below to add them here")
        field.showSoftInputOnFocus = false
        c.addView(field)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp1 = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        lp1.rightMargin = Ui.dp(this, 6)
        val lp2 = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        lp2.leftMargin = Ui.dp(this, 6)
        buttons.addView(Ui.button(this, "Copy all") {
            val text = field.text.toString()
            if (text.isNotEmpty()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("text", text))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
        }, lp1)
        buttons.addView(Ui.button(this, "Clear", Ui.CHIP) { field.setText("") }, lp2)
        Ui.add(c, buttons, 10)

        Ui.add(c, Ui.body(this, "These same panels are inside your keyboard: tap the 😀 or ✨ button.", 13f), 10)

        val file = if (isEmoji) "emoji.txt" else "symbols.txt"
        val cats = GlyphData.load(applicationContext, file)
        val panel = GlyphPanel.build(this, cats, Themes.all[0], Ui.dp(this, 360)) { g ->
            val pos = field.selectionStart.coerceAtLeast(0)
            field.text.insert(pos, g)
            Toast.makeText(this, g, Toast.LENGTH_SHORT).show()
        }
        Ui.add(c, panel, 10)
    }
}
