package lk.example.sinhalakeyboard

import android.content.Context
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

data class NewsSource(val id: String, val name: String, val url: String, val defaultOn: Boolean)

data class NewsItem(val title: String, val link: String, val source: String, val time: Long)

object News {

    val SOURCES = listOf(
        NewsSource("ada_si", "Ada Derana (Sinhala)", "https://sinhala.adaderana.lk/rss.php", true),
        NewsSource("ada_en", "Ada Derana (English)", "https://www.adaderana.lk/rss.php", true),
        NewsSource("dinamina", "Dinamina (Sinhala)", "https://www.dinamina.lk/feed/", true),
        NewsSource("dailynews", "Daily News", "https://www.dailynews.lk/feed/", false),
        NewsSource("island", "The Island", "https://island.lk/feed/", false),
        NewsSource("economynext", "EconomyNext", "https://economynext.com/feed/", false)
    )

    fun prefKey(s: NewsSource) = "news_src_" + s.id

    fun enabled(ctx: Context): List<NewsSource> {
        val p = Prefs.of(ctx)
        return SOURCES.filter { p.getBoolean(prefKey(it), it.defaultOn) }
    }

    /** Downloads every enabled feed. A feed that fails is skipped. Call from a background thread. */
    fun fetch(ctx: Context): List<NewsItem> {
        val all = LinkedHashMap<String, NewsItem>()
        for (s in enabled(ctx)) {
            try {
                for (it in parse(s)) if (!all.containsKey(it.link)) all[it.link] = it
            } catch (e: Exception) {
                // ignore this feed
            }
        }
        return all.values.sortedByDescending { it.time }
    }

    private fun parse(s: NewsSource): List<NewsItem> {
        val conn = URL(s.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) SinhalaKeyboard")
        val out = ArrayList<NewsItem>()
        try {
            if (conn.responseCode !in 200..299) return out
            val parser = Xml.newPullParser()
            parser.setInput(conn.inputStream, null)
            val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.ENGLISH)
            var inItem = false
            var title = ""
            var link = ""
            var date = 0L
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT && out.size < 15) {
                if (ev == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "item" -> { inItem = true; title = ""; link = ""; date = 0L }
                        "title" -> if (inItem) title = clean(parser.nextText())
                        "link" -> if (inItem) link = parser.nextText().trim()
                        "pubDate" -> if (inItem) {
                            val raw = parser.nextText().trim()
                            date = try { fmt.parse(raw)?.time ?: 0L } catch (e: Exception) { 0L }
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG && parser.name == "item") {
                    inItem = false
                    if (title.isNotEmpty() && link.startsWith("http")) out.add(NewsItem(title, link, s.name, date))
                }
                ev = parser.next()
            }
        } finally {
            conn.disconnect()
        }
        return out
    }

    private fun clean(s: String): String =
        s.replace(Regex("<[^>]*>"), "").replace("&nbsp;", " ").replace(Regex("\\s+"), " ").trim()

    fun ago(time: Long): String {
        if (time <= 0L) return ""
        val mins = (System.currentTimeMillis() - time) / 60000
        return when {
            mins < 1 -> "just now"
            mins < 60 -> "$mins min ago"
            mins < 1440 -> "${mins / 60} h ago"
            else -> "${mins / 1440} d ago"
        }
    }
}
