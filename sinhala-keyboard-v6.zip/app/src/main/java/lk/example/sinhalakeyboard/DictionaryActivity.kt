package lk.example.sinhalakeyboard

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class DictionaryActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Dictionary")
        Ui.add(c, Ui.body(this, "Words the keyboard has learned from you. They appear first in suggestions.", 14f), 6)

        input = Ui.inputField(this, "Add a Sinhala word")
        Ui.add(c, input, 14)
        Ui.add(c, Ui.button(this, "Add word") { addWord() }, 10)

        count = Ui.heading(this, "")
        Ui.add(c, count, 14)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.add(c, list, 4)

        Ui.add(c, Ui.button(this, "Clear all learned words", 0xFFFF7A7A.toInt()) {
            Prefs.learned(this).edit().clear().apply()
            render()
        }, 18)
        render()
    }

    private fun addWord() {
        val w = input.text.toString().trim()
        if (w.isEmpty()) return
        val prefs = Prefs.learned(this)
        prefs.edit().putInt(w, prefs.getInt(w, 0) + 3).apply()
        input.setText("")
        Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun render() {
        list.removeAllViews()
        val words = Prefs.learned(this).all
            .mapNotNull { (k, v) -> if (v is Int) Pair(k, v) else null }
            .sortedByDescending { it.second }
        count.text = "LEARNED WORDS (${words.size}) - TAP TO REMOVE"
        for ((w, n) in words.take(300)) {
            val row = Ui.card(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(TextView(this).apply {
                text = w
                textSize = 18f
                setTextColor(Ui.TEXT)
            }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            row.addView(TextView(this).apply {
                text = "×$n"
                textSize = 14f
                setTextColor(Ui.MUTED)
            })
            row.setOnClickListener {
                Prefs.learned(this).edit().remove(w).apply()
                render()
            }
            Ui.add(list, row as View, 6)
        }
        if (words.isEmpty()) {
            Ui.add(list, Ui.body(this, "Nothing yet. Words you type will show up here.", 14f), 8)
        }
    }
}
