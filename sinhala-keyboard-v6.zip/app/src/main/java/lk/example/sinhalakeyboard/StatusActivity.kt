package lk.example.sinhalakeyboard

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

/** A frame that is as tall as it is wide. */
class SquareFrame(ctx: Context) : FrameLayout(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, w)
        setMeasuredDimension(measuredWidth, measuredWidth)
    }
}

private data class StatusFile(val uri: Uri, val name: String, val mime: String, val time: Long)

/**
 * Shows the photos and videos from WhatsApp statuses you have already viewed, and saves them to the gallery.
 * Android does not let apps read the WhatsApp folder directly, so you pick that folder once.
 */
class StatusActivity : Activity() {

    private lateinit var holder: LinearLayout
    private val pool = Executors.newFixedThreadPool(3)
    private var pendingSave: StatusFile? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Status Saver")
        Ui.add(c, Ui.body(this, "Open a friend's WhatsApp status first, then come back here to save it. Tap a picture to view it, tap Save to keep it in your gallery.", 14f), 6)
        holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.add(c, holder, 10)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onDestroy() {
        super.onDestroy()
        pool.shutdownNow()
    }

    private fun render() {
        holder.removeAllViews()
        val saved = Prefs.of(this).getString(Prefs.STATUS_TREE, null)
        if (saved == null) {
            val card = Ui.card(this)
            card.addView(Ui.label(this, "Choose the WhatsApp folder"))
            card.addView(Ui.body(this, "Tap the button, then tap \"Use this folder\" at the bottom. The right folder is already opened for you. If you use WhatsApp Business, pick its folder instead.", 13f))
            Ui.add(card, Ui.button(this, "Choose folder") { pickFolder(false) }, 12)
            Ui.add(card, Ui.button(this, "WhatsApp Business folder", 0xFF4DD0E1.toInt()) { pickFolder(true) }, 8)
            Ui.add(holder, card, 4)
            return
        }
        val tree = Uri.parse(saved)
        val note = Ui.body(this, "Loading...", 14f)
        Ui.add(holder, note, 4)
        Thread {
            val files = try { listStatuses(tree) } catch (e: Exception) { null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                holder.removeAllViews()
                showFiles(files)
            }
        }.start()
    }

    private fun showFiles(files: List<StatusFile>?) {
        if (files == null) {
            Ui.add(holder, Ui.body(this, "Could not open that folder. Please choose it again.", 14f), 4)
        } else if (files.isEmpty()) {
            Ui.add(holder, Ui.body(this, "No statuses yet. View some statuses in WhatsApp, then open this screen again.", 14f), 4)
        } else {
            val cells = files.map { cell(it) }
            Ui.add(holder, Ui.grid(this, cells, 3, 4), 4)
        }
        Ui.add(holder, Ui.button(this, "Refresh") { render() }, 16)
        Ui.add(holder, Ui.button(this, "Change folder", Ui.CHIP) {
            Prefs.of(this).edit().remove(Prefs.STATUS_TREE).apply()
            render()
        }, 8)
    }

    private fun cell(f: StatusFile): View {
        val frame = SquareFrame(this)
        frame.setBackgroundColor(Ui.CARD)
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        frame.addView(img, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        val isVideo = f.mime.startsWith("video/")
        pool.execute {
            val bmp = thumbnail(f, isVideo)
            runOnUiThread { if (!isDestroyed && bmp != null) img.setImageBitmap(bmp) }
        }
        if (isVideo) {
            frame.addView(TextView(this).apply {
                text = "▶"
                textSize = 26f
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        }
        val save = TextView(this).apply {
            text = "Save"
            textSize = 13f
            setTextColor(0xFF101010.toInt())
            gravity = Gravity.CENTER
            background = Ui.pill(Ui.ACCENT)
            setPadding(Ui.dp(context, 10), Ui.dp(context, 5), Ui.dp(context, 10), Ui.dp(context, 5))
            setOnClickListener { save(f) }
        }
        val lp = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, Ui.dp(this, 6), Ui.dp(this, 6))
        frame.addView(save, lp)
        frame.setOnClickListener {
            try {
                val i = Intent(Intent.ACTION_VIEW).setDataAndType(f.uri, f.mime)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(this, "No app found to open this", Toast.LENGTH_SHORT).show()
            }
        }
        return frame
    }

    private fun thumbnail(f: StatusFile, video: Boolean): Bitmap? {
        return try {
            if (video) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(this, f.uri)
                    r.getFrameAtTime(0)
                } finally {
                    r.release()
                }
            } else {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(f.uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (o.outWidth / (s * 2) >= 300) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                contentResolver.openInputStream(f.uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- choosing the folder ----------

    private fun pickFolder(business: Boolean) {
        val pkg = if (business) "com.whatsapp.w4b" else "com.whatsapp"
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        val start = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            "primary:Android/media/$pkg/WhatsApp/Media/.Statuses"
        )
        i.putExtra("android.provider.extra.INITIAL_URI", start)
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        try {
            startActivityForResult(i, 21)
        } catch (e: Exception) {
            Toast.makeText(this, "This phone cannot open the folder picker", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 21 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // still usable for this session
        }
        Prefs.of(this).edit().putString(Prefs.STATUS_TREE, uri.toString()).apply()
    }

    private fun children(tree: Uri, docId: String): List<Triple<String, String, String>> {
        val out = ArrayList<Triple<String, String, String>>()
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        contentResolver.query(
            kids,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) out.add(Triple(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: ""))
        }
        return out
    }

    /** The picked folder is either the .Statuses folder itself or a folder above it. */
    private fun statusesFolderId(tree: Uri): String {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        if (rootId.endsWith(".Statuses")) return rootId
        var level = listOf(rootId)
        repeat(4) {
            val next = ArrayList<String>()
            for (id in level) {
                for ((cid, name, mime) in children(tree, id)) {
                    if (mime != DocumentsContract.Document.MIME_TYPE_DIR) continue
                    if (name == ".Statuses") return cid
                    next.add(cid)
                }
            }
            level = next
        }
        return rootId
    }

    private fun listStatuses(tree: Uri): List<StatusFile> {
        val folder = statusesFolderId(tree)
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, folder)
        val out = ArrayList<StatusFile>()
        contentResolver.query(
            kids,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val mime = c.getString(2) ?: ""
                if (mime.startsWith("image/") || mime.startsWith("video/")) {
                    out.add(
                        StatusFile(
                            DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)),
                            c.getString(1) ?: "status", mime, c.getLong(3)
                        )
                    )
                }
            }
        } ?: throw IllegalStateException("no access")
        return out.sortedByDescending { it.time }
    }

    // ---------- saving ----------

    private fun save(f: StatusFile) {
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = f
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 31)
            return
        }
        Thread {
            val ok = try { copyToGallery(f) } catch (e: Exception) { false }
            runOnUiThread {
                Toast.makeText(
                    this,
                    if (ok) "Saved to your gallery (Status Saver)" else "Could not save this one",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }.start()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        val f = pendingSave
        pendingSave = null
        if (code == 31 && f != null && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) save(f)
    }

    private fun copyToGallery(f: StatusFile): Boolean {
        val video = f.mime.startsWith("video/")
        val ext = if (video) "mp4" else "jpg"
        val base = (f.name.substringBeforeLast('.', f.name)).ifEmpty { "status" }
        val fileName = "$base.$ext"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, f.mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    (if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES) + "/Status Saver"
                )
            }
            val target = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val dest = contentResolver.insert(target, values) ?: return false
            contentResolver.openInputStream(f.uri)?.use { input ->
                contentResolver.openOutputStream(dest)?.use { output -> input.copyTo(output) }
            } ?: return false
            return true
        }
        val dir = File(
            Environment.getExternalStoragePublicDirectory(
                if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
            ),
            "Status Saver"
        )
        dir.mkdirs()
        val out = File(dir, fileName)
        contentResolver.openInputStream(f.uri)?.use { input -> out.outputStream().use { input.copyTo(it) } } ?: return false
        MediaScannerConnection.scanFile(this, arrayOf(out.absolutePath), arrayOf(f.mime), null)
        return true
    }
}
