package lk.example.sinhalakeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private var setupCard: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "සිංහ keyboard", back = false)
        if (savedInstanceState == null) showSplash()

        c.addView(Ui.rgbText(this, "Developed by Shashendra Nirvan", 15f))
        Ui.add(c, Ui.inputField(this, "Test your keyboard"), 10)

        val card = Ui.card(this)
        card.addView(Ui.label(this, "Turn on the keyboard"))
        card.addView(Ui.body(this, "1. Enable it in system settings, then 2. choose it as your active keyboard.", 13f))
        Ui.add(card, Ui.button(this, "1. Enable keyboard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        Ui.add(card, Ui.button(this, "2. Select keyboard", 0xFF4DD0E1.toInt()) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        setupCard = card
        Ui.add(c, card, 14)

        fun open(cls: Class<*>, kind: String? = null) {
            val i = Intent(this, cls)
            if (kind != null) i.putExtra("kind", kind)
            startActivity(i)
        }

        val tiles = listOf(
            Ui.tileIcon(this, Ic.THEME, "Themes", 0xFF7C6CFF.toInt()) { open(ThemesActivity::class.java) },
            Ui.tileIcon(this, Ic.WALL, "2D Wallpapers", 0xFF00C2FF.toInt()) { open(WallpapersActivity::class.java, "2d") },
            Ui.tileIcon(this, Ic.HD, "HD Wallpapers", 0xFF26C6DA.toInt()) { open(WallpapersActivity::class.java, "hd") },
            Ui.tileIcon(this, Ic.SPARKLE, "HD Live Themes", 0xFFFF5252.toInt()) { open(WallpapersActivity::class.java, "live") },
            Ui.tileIcon(this, Ic.RGB, "RGB Lights", 0xFFFF2BD6.toInt()) { open(RgbActivity::class.java) },
            Ui.tileIcon(this, Ic.EMOJI, "Emojis", 0xFFFFC857.toInt()) { open(GlyphBrowserActivity::class.java, "emoji") },
            Ui.tileIcon(this, Ic.SPARKLE, "Epic Symbols", 0xFFFF6FB5.toInt()) { open(GlyphBrowserActivity::class.java, "symbols") },
            Ui.tileIcon(this, Ic.BOLT, "Fast Typing", 0xFFFF9800.toInt()) { open(FastTypingActivity::class.java) },
            Ui.tileIcon(this, Ic.NEWS, "News Alerts", 0xFFEF5350.toInt()) { open(NewsActivity::class.java) },
            Ui.tileIcon(this, Ic.DOWNLOAD, "Status Saver", 0xFF25D366.toInt()) { open(StatusActivity::class.java) },
            Ui.tileIcon(this, Ic.GLOBE, "Browser", 0xFF42A5F5.toInt()) { open(BrowserActivity::class.java) },
            Ui.tileIcon(this, Ic.CHAT, "AI Assistant", 0xFF00E5FF.toInt()) { open(AiActivity::class.java) },
            Ui.tileIcon(this, Ic.GEAR, "Settings", 0xFF8C9EFF.toInt()) { open(SettingsActivity::class.java) },
            Ui.tileIcon(this, Ic.BOOK, "Dictionary", 0xFFB388FF.toInt()) { open(DictionaryActivity::class.java) },
            Ui.tileIcon(this, Ic.HELP, "Help", 0xFFFFA726.toInt()) { open(HelpActivity::class.java) },
            Ui.tileIcon(this, Ic.INFO, "About", 0xFF66BB6A.toInt()) { showAbout() }
        )
        Ui.add(c, Ui.grid(this, tiles, 3, 4), 8)
        Ui.add(c, Ui.choiceRow(this, "App mode", listOf("Dark", "Light", "Auto"), Prefs.APP_MODE, 0) { recreate() }, 14)
    }

    private fun showSplash() {
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Ui.BG)
            isClickable = true
            alpha = 0f
        }
        overlay.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_fg)
        }, LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.dp(this, 150)))
        overlay.addView(TextView(this).apply {
            text = "සිංහ keyboard"
            textSize = 32f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        overlay.addView(Ui.body(this, "Developed by", 14f), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply {
            topMargin = Ui.dp(this@MainActivity, 18)
        })
        overlay.addView(Ui.rgbText(this, "Shashendra Nirvan", 28f), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply {
            topMargin = Ui.dp(this@MainActivity, 4)
        })
        addContentView(overlay, ViewGroup.LayoutParams(Ui.MATCH, Ui.MATCH))
        overlay.animate().alpha(1f).setDuration(500).withEndAction {
            overlay.postDelayed({
                overlay.animate().alpha(0f).setDuration(500).withEndAction {
                    (overlay.parent as? ViewGroup)?.removeView(overlay)
                }.start()
            }, 1600)
        }.start()
    }

    override fun onResume() {
        super.onResume()
        setupCard?.visibility = if (isKeyboardEnabled()) View.GONE else View.VISIBLE
    }

    private fun isKeyboardEnabled(): Boolean {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("සිංහ keyboard 1.8")
            .setMessage(
                "Type Sinhala using English letters (Singlish).\n\n" +
                    "• Word suggestions that learn from you\n" +
                    "• 25 themes, 2D live wallpapers, 33 HD wallpapers and RGB lighting\n" +
                    "• Full emoji and symbol panels\n" +
                    "• Fast typing mode\n" +
                    "• News alerts, WhatsApp Status Saver and clipboard pins\n" +
                    "• AI Assistant chat and a built-in browser\n\n" +
                    "Developed by Shashendra Nirvan\n\n" +
                    "Nothing you type on the keyboard leaves your phone. The internet is used for news headlines and the AI Assistant (only what you send in that chat)."
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
