package lk.example.sinhalakeyboard

import android.app.Activity
import android.os.Bundle

class HelpActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Ui.screen(this, "Help")

        fun section(title: String, text: String) {
            Ui.add(c, Ui.heading(this, title), 10)
            val card = Ui.card(this)
            card.addView(Ui.body(this, text, 15f))
            Ui.add(c, card, 6)
        }

        section(
            "TURN ON THE KEYBOARD",
            "1. Tap \"Enable keyboard\" on the home screen and switch Sinhala Keyboard on.\n" +
                "2. Tap \"Select keyboard\" and choose Sinhala Keyboard.\n" +
                "3. Open any app and start typing."
        )
        section(
            "TYPING SINHALA (SINGLISH)",
            "Type with English letters and the keyboard converts them.\n\n" +
                "mama  →  මම\noya  →  ඔය\nkohomada  →  කොහොමද\namma  →  අම්ම\n\n" +
                "Tap a suggestion to finish the word. The last suggestion is what you typed, in English letters."
        )
        section(
            "LETTER GUIDE",
            "Capital letters give the heavy sounds:\nT ට   D ඩ   N ණ   L ළ   S ශ   Sh ෂ\n\n" +
                "Two-letter sounds:\nth ථ   dh ධ   kh ඛ   gh ඝ   ch ච   ph ඵ   bh භ\nnd ඳ   mb ඹ   ng ඟ\n\n" +
                "Vowels:\na අ   aa ආ   ae ඇ   aae ඈ   i ඉ   ii ඊ\nu උ   uu ඌ   e එ   ee ඒ   o ඔ   oo ඕ   ai ඓ   au ඖ"
        )
        section(
            "RARE LETTERS",
            "Letters like ඍ ඤ ඥ ශ්‍රී are in Epic Symbols, in the Sinhala tab (the අ tab). " +
                "Open the ✨ panel from the keyboard to use them."
        )
        section(
            "EMOJIS AND SYMBOLS",
            "Tap 😀 on the keyboard for emojis, flags and more. Tap ✨ for stars, arrows, currency, " +
                "decorations and text faces. Recent items appear first."
        )
        section(
            "THEMES AND LIVE WALLPAPERS",
            "Pick a theme and an animated background in the app, or use the 🎨 and 🌌 buttons on the " +
                "bar above the keys to flip through them."
        )
        section(
            "FAST TYPING",
            "Instant key press types the moment you touch a key. Double-space adds a full stop. " +
                "Hold the backspace key to delete quickly. See the Fast Typing screen for all options."
        )
        section(
            "PRIVACY",
            "Everything you type stays on your phone. The keyboard has no internet access and sends " +
                "nothing anywhere."
        )
    }
}
