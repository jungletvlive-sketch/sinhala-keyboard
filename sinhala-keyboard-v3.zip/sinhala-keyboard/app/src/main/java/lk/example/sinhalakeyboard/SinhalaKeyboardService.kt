package lk.example.sinhalakeyboard

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SinhalaKeyboardService : InputMethodService() {

    private enum class Panel { LETTERS, NUMBERS, NUMBERS2, EMOJI, SYMBOLS }

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var kbTheme: KbTheme = Themes.all[0]
    private var wallpaper = 0
    private var panel = Panel.LETTERS
    private var sinhalaMode = true
    private var shift = false
    private var capsLock = false
    private var lastShiftTap = 0L

    private var fast = true
    private var vibrate = true
    private var sound = false
    private var repeatMs = 55L
    private var keyHeightDp = 48
    private var numberRow = false
    private var suggestOn = true
    private var learnOn = true
    private var doubleSpace = true
    private var autoCap = true

    private val buffer = StringBuilder()
    private val letterKeys = ArrayList<Pair<TextView, Char>>()
    private var shiftKey: TextView? = null
    private var suggestionRow: LinearLayout? = null
    private var inputRoot: View? = null

    private val learnedCache = HashMap<String, Int>()
    private var builtinWords: List<String> = emptyList()
    private var dirty = true
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> dirty = true }

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.of(this)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        builtinWords = try {
            assets.open("words.txt").bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() }
        } catch (e: Exception) {
            emptyList()
        }
        reloadLearned()
        Thread {
            GlyphData.load(applicationContext, "emoji.txt")
            GlyphData.load(applicationContext, "symbols.txt")
        }.start()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        loadSettings()
        dirty = false
        return buildView()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) {
            reloadLearned()
            buffer.clear()
            shift = false
            capsLock = false
            val needRebuild = dirty || panel != Panel.LETTERS
            panel = Panel.LETTERS
            if (needRebuild) {
                dirty = false
                loadSettings()
                setInputView(buildView())
            } else {
                updateSuggestions()
                updateShiftUi()
            }
        }
        autoCapFromContext()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        commitComposing()
        super.onFinishInputView(finishingInput)
    }

    private fun reloadLearned() {
        learnedCache.clear()
        for ((k, v) in Prefs.learned(this).all) {
            if (v is Int) learnedCache[k] = v
        }
    }

    private fun loadSettings() {
        kbTheme = Themes.all[prefs.getInt(Prefs.THEME, 0).coerceIn(0, Themes.all.size - 1)]
        wallpaper = prefs.getInt(Prefs.WALLPAPER, 0).coerceIn(0, Wallpapers.names.size - 1)
        fast = prefs.getBoolean(Prefs.FAST, true)
        vibrate = prefs.getBoolean(Prefs.VIBRATE, true)
        sound = prefs.getBoolean(Prefs.SOUND, false)
        repeatMs = when (prefs.getInt(Prefs.REPEAT, 1)) {
            0 -> 90L
            2 -> 32L
            else -> 55L
        }
        keyHeightDp = when (prefs.getInt(Prefs.HEIGHT, 1)) {
            0 -> 42
            2 -> 56
            else -> 48
        }
        numberRow = prefs.getBoolean(Prefs.NUMBER_ROW, false)
        suggestOn = prefs.getBoolean(Prefs.SUGGEST, true)
        learnOn = prefs.getBoolean(Prefs.LEARN, true)
        doubleSpace = prefs.getBoolean(Prefs.DOUBLE_SPACE, true)
        autoCap = prefs.getBoolean(Prefs.AUTO_CAP, true)
        sinhalaMode = prefs.getBoolean(Prefs.SINHALA, true)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun refresh() = setInputView(buildView())
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- views ----------

    private fun buildView(): View {
        letterKeys.clear()
        shiftKey = null
        val frame = FrameLayout(this)
        val bg = LiveWallpaperView(this)
        bg.configure(wallpaper, kbTheme)
        frame.addView(
            bg,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(6))
        }
        content.addView(suggestionStrip())
        when (panel) {
            Panel.LETTERS -> letterRows(content)
            Panel.NUMBERS -> numberRows(content, false)
            Panel.NUMBERS2 -> numberRows(content, true)
            Panel.EMOJI -> glyphPanel(content, "emoji.txt", "emoji")
            Panel.SYMBOLS -> glyphPanel(content, "symbols.txt", "symbols")
        }
        frame.addView(
            content,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        inputRoot = frame
        updateSuggestions()
        return frame
    }

    private fun suggestionStrip(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        suggestionRow = row
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        }
    }

    private fun chip(text: String, size: Float, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        setTextColor(kbTheme.accent)
        textSize = size
        gravity = Gravity.CENTER
        setPadding(dp(14), 0, dp(14), 0)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )
        setOnClickListener { onClick() }
    }

    private fun updateSuggestions() {
        val row = suggestionRow ?: return
        row.removeAllViews()
        if (sinhalaMode && buffer.isNotEmpty()) {
            val raw = buffer.toString()
            val current = Transliterator.convert(raw)
            val items = LinkedHashSet<String>()
            items.add(current)
            if (suggestOn) items.addAll(matches(current.removeSuffix("්"), current))
            items.add(raw)
            for (w in items) row.addView(chip(w, 18f) { pick(w) })
        } else {
            row.addView(chip("⚙", 20f) { openApp() })
            row.addView(chip("🎨", 20f) { cycleTheme() })
            row.addView(chip("🌌", 20f) { cycleWallpaper() })
            row.addView(chip("⚡", 20f) { toggleFast() })
            row.addView(chip("😀", 20f) { switchPanel(Panel.EMOJI) })
            row.addView(chip("✨", 20f) { switchPanel(Panel.SYMBOLS) })
        }
    }

    private fun matches(prefix: String, exclude: String): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val user = learnedCache.entries
            .filter { it.key.startsWith(prefix) && it.key != exclude }
            .sortedByDescending { it.value }
            .map { it.key }
        val builtin = builtinWords.filter { it.startsWith(prefix) && it != exclude }
        return (user + builtin).distinct().take(8)
    }

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(keyHeightDp))
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
    }

    private fun keyBackground(special: Boolean): StateListDrawable {
        val alphaN = if (wallpaper != 0) 0xC8 else 0xFF
        val normal = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Themes.alpha(if (special) kbTheme.special else kbTheme.key, alphaN))
        }
        val pressed = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Themes.alpha(kbTheme.accent, 0xB0))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    private fun key(
        text: String,
        weight: Float,
        special: Boolean = false,
        repeat: Boolean = false,
        action: () -> Unit
    ): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(kbTheme.text)
        tv.textSize = if (text.length > 2) 14f else 19f
        tv.gravity = Gravity.CENTER
        tv.background = keyBackground(special)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        tv.layoutParams = lp
        attachTouch(tv, repeat, action)
        return tv
    }

    private fun attachTouch(v: View, repeat: Boolean, action: () -> Unit) {
        var repeater: Runnable? = null
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    if (fast || repeat) {
                        feedback(view)
                        action()
                    }
                    if (repeat) {
                        val r = object : Runnable {
                            override fun run() {
                                feedback(view)
                                action()
                                handler.postDelayed(this, repeatMs)
                            }
                        }
                        repeater = r
                        handler.postDelayed(r, 380L)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    repeater?.let { handler.removeCallbacks(it) }
                    repeater = null
                    if (!fast && !repeat) {
                        val inside = ev.x >= 0f && ev.x <= view.width && ev.y >= 0f && ev.y <= view.height
                        if (inside) {
                            feedback(view)
                            action()
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    repeater?.let { handler.removeCallbacks(it) }
                    repeater = null
                }
            }
            true
        }
    }

    @Suppress("DEPRECATION")
    private fun feedback(v: View?) {
        if (vibrate) {
            v?.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
        if (sound) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
    }

    private fun letterLabel(ch: Char): String = if (shift || capsLock) ch.uppercaseChar().toString() else ch.toString()
    private fun shiftLabel(): String = if (capsLock) "⇪" else if (shift) "⬆" else "⇧"

    private fun letterRows(root: LinearLayout) {
        if (numberRow) {
            val row = newRow()
            for (ch in "1234567890") row.addView(key(ch.toString(), 1f) { onSymbol(ch.toString()) })
            root.addView(row)
        }
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        for ((idx, r) in rows.withIndex()) {
            val row = newRow()
            if (idx == 1) row.addView(spacer(0.5f))
            if (idx == 2) {
                val sk = key(shiftLabel(), 1.5f, special = true) { onShift() }
                shiftKey = sk
                row.addView(sk)
            }
            for (ch in r) {
                val k = key(letterLabel(ch), 1f) { onLetter(ch) }
                letterKeys.add(Pair(k, ch))
                row.addView(k)
            }
            if (idx == 2) row.addView(key("⌫", 1.5f, special = true, repeat = true) { onBackspace() })
            if (idx == 1) row.addView(spacer(0.5f))
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("?123", 1.3f, special = true) { switchPanel(Panel.NUMBERS) })
        bottom.addView(key("😀", 1.1f, special = true) { switchPanel(Panel.EMOJI) })
        bottom.addView(key(if (sinhalaMode) "SI" else "EN", 1.1f, special = true) { toggleLanguage() })
        bottom.addView(key(",", 0.9f) { onSymbol(",") })
        bottom.addView(key("space", 3f) { onSpace() })
        bottom.addView(key(".", 0.9f) { onSymbol(".") })
        bottom.addView(key("↵", 1.4f, special = true) { onEnter() })
        root.addView(bottom)
    }

    private fun numberRows(root: LinearLayout, second: Boolean) {
        val rows = if (!second) {
            listOf("1234567890", "@#\$%&-+()/", "!?:;\"'*=_")
        } else {
            listOf("~`|•√π÷×¶∆", "£¢€¥^°={}\\", "©®™✓[]<>%")
        }
        for ((idx, r) in rows.withIndex()) {
            val row = newRow()
            for (ch in r) row.addView(key(ch.toString(), 1f) { onSymbol(ch.toString()) })
            if (idx == 2) row.addView(key("⌫", 1.5f, special = true, repeat = true) { onBackspace() })
            root.addView(row)
        }
        val bottom = newRow()
        bottom.addView(key("ABC", 1.6f, special = true) { switchPanel(Panel.LETTERS) })
        bottom.addView(key(if (second) "1/2" else "2/2", 1.2f, special = true) {
            switchPanel(if (second) Panel.NUMBERS else Panel.NUMBERS2)
        })
        bottom.addView(key(",", 1f) { onSymbol(",") })
        bottom.addView(key("space", 3.5f) { onSpace() })
        bottom.addView(key(".", 1f) { onSymbol(".") })
        bottom.addView(key("↵", 1.6f, special = true) { onEnter() })
        root.addView(bottom)
    }

    private fun glyphPanel(root: LinearLayout, file: String, kind: String) {
        val cats = GlyphData.withRecents(applicationContext, kind, file)
        val gridH = dp(keyHeightDp) * 3
        root.addView(GlyphPanel.build(this, cats, kbTheme, gridH) { g -> onGlyph(g, kind) })
        val bottom = newRow()
        bottom.addView(key("ABC", 2f, special = true) { switchPanel(Panel.LETTERS) })
        if (kind == "emoji") {
            bottom.addView(key("✨", 1.5f, special = true) { switchPanel(Panel.SYMBOLS) })
        } else {
            bottom.addView(key("😀", 1.5f, special = true) { switchPanel(Panel.EMOJI) })
        }
        bottom.addView(key("space", 4f) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(key("⌫", 2f, special = true, repeat = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(bottom)
    }

    private fun updateShiftUi() {
        for ((tv, ch) in letterKeys) tv.text = letterLabel(ch)
        shiftKey?.text = shiftLabel()
    }

    // ---------- actions ----------

    private fun switchPanel(p: Panel) {
        commitComposing()
        panel = p
        refresh()
    }

    private fun toggleLanguage() {
        commitComposing()
        sinhalaMode = !sinhalaMode
        prefs.edit().putBoolean(Prefs.SINHALA, sinhalaMode).apply()
        refresh()
        autoCapFromContext()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun cycleTheme() {
        val i = (Themes.all.indexOf(kbTheme) + 1) % Themes.all.size
        prefs.edit().putInt(Prefs.THEME, i).apply()
        kbTheme = Themes.all[i]
        toast(kbTheme.name)
        refresh()
    }

    private fun cycleWallpaper() {
        wallpaper = (wallpaper + 1) % Wallpapers.names.size
        prefs.edit().putInt(Prefs.WALLPAPER, wallpaper).apply()
        toast(Wallpapers.names[wallpaper])
        refresh()
    }

    private fun toggleFast() {
        fast = !fast
        prefs.edit().putBoolean(Prefs.FAST, fast).apply()
        toast(if (fast) "Fast typing ON" else "Fast typing OFF")
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350L) {
            capsLock = true
            shift = true
        } else if (capsLock) {
            capsLock = false
            shift = false
        } else {
            shift = !shift
        }
        lastShiftTap = now
        updateShiftUi()
    }

    private fun onLetter(base: Char) {
        val up = shift || capsLock
        val c = if (up) base.uppercaseChar() else base
        if (shift && !capsLock) {
            shift = false
            updateShiftUi()
        }
        if (sinhalaMode) {
            buffer.append(c)
            currentInputConnection?.setComposingText(Transliterator.convert(buffer.toString()), 1)
            updateSuggestions()
        } else {
            currentInputConnection?.commitText(c.toString(), 1)
        }
    }

    private fun onBackspace() {
        if (buffer.isNotEmpty()) {
            buffer.deleteCharAt(buffer.length - 1)
            val ic = currentInputConnection
            if (buffer.isEmpty()) {
                ic?.commitText("", 1)
            } else {
                ic?.setComposingText(Transliterator.convert(buffer.toString()), 1)
            }
            updateSuggestions()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun onSpace() {
        commitComposing()
        val ic = currentInputConnection ?: return
        if (doubleSpace) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' &&
                before[0] != ' ' && before[0] !in ".,!?;:"
            ) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                autoCapFromContext()
                return
            }
        }
        ic.commitText(" ", 1)
        autoCapFromContext()
    }

    private fun onSymbol(s: String) {
        commitComposing()
        currentInputConnection?.commitText(s, 1)
        autoCapFromContext()
    }

    private fun onEnter() {
        commitComposing()
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
            ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        autoCapFromContext()
    }

    private fun onGlyph(g: String, kind: String) {
        feedback(inputRoot)
        commitComposing()
        currentInputConnection?.commitText(g, 1)
        GlyphData.addRecent(applicationContext, kind, g)
    }

    private fun pick(word: String) {
        currentInputConnection?.commitText("$word ", 1)
        learn(word)
        buffer.clear()
        updateSuggestions()
    }

    private fun commitComposing() {
        if (buffer.isEmpty()) return
        val word = Transliterator.convert(buffer.toString())
        currentInputConnection?.commitText(word, 1)
        learn(word)
        buffer.clear()
        updateSuggestions()
    }

    private fun autoCapFromContext() {
        if (!autoCap || sinhalaMode || capsLock) return
        val ei = currentInputEditorInfo ?: return
        if (ei.inputType == 0) return
        val mode = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        val want = mode != 0
        if (want != shift) {
            shift = want
            updateShiftUi()
        }
    }

    private fun learn(word: String) {
        if (!learnOn || word.length < 2 || word[0].code !in 0x0D80..0x0DFF) return
        val n = (learnedCache[word] ?: 0) + 1
        learnedCache[word] = n
        Prefs.learned(this).edit().putInt(word, n).apply()
    }
}
