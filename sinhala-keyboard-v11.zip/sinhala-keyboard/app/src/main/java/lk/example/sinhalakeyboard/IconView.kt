package lk.example.sinhalakeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

enum class Ic {
    LANG, EMOJI, SPARKLE, CLIP, DOWNLOAD, RGB, THEME, WALL, BOLT, GEAR, BOOK, HELP, INFO,
    NEWS, CHEVRON, PIN, TRASH, CHAT, HD, GLOBE
}

/**
 * A clean line icon, optionally inside a soft translucent circle (the round toolbar buttons).
 * Everything is drawn in code on a 24 x 24 grid, so it stays sharp on any screen.
 */
class IconView(
    context: Context,
    private val kind: Ic,
    private val label: String = "",
    private val circle: Boolean = true,
    var iconColor: Int = Color.WHITE,
    var circleColor: Int = 0x38FFFFFF,
    var filled: Boolean = false
) : View(context) {

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val p = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val size = minOf(w, h)
        if (circle) {
            fill.shader = null
            fill.color = circleColor
            c.drawCircle(w / 2, h / 2, size / 2, fill)
        }
        // the icon uses the middle 52 percent of the circle
        val box = size * (if (circle) 0.52f else 0.9f)
        val s = box / 24f
        c.save()
        c.translate(w / 2 - 12 * s, h / 2 - 12 * s)
        c.scale(s, s)
        stroke.color = iconColor
        stroke.strokeWidth = 2f
        fill.color = iconColor
        draw(c, s)
        c.restore()
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, stroke)

    private fun draw(c: Canvas, s: Float) {
        when (kind) {
            Ic.LANG -> {
                text.color = iconColor
                text.textSize = 11f
                c.drawText(label, 12f, 16f, text)
            }
            Ic.EMOJI -> {
                c.drawCircle(12f, 12f, 9.5f, stroke)
                c.drawCircle(8.7f, 9.8f, 1.2f, fill)
                c.drawCircle(15.3f, 9.8f, 1.2f, fill)
                c.drawArc(RectF(7f, 7.5f, 17f, 17f), 20f, 140f, false, stroke)
            }
            Ic.SPARKLE -> {
                star(c, 10f, 13f, 8f, true)
                star(c, 18.5f, 5.5f, 3.4f, true)
                star(c, 18f, 18.5f, 2.6f, true)
            }
            Ic.CLIP -> {
                c.drawRoundRect(RectF(5f, 4.5f, 19f, 21f), 2.5f, 2.5f, stroke)
                c.drawRoundRect(RectF(8.5f, 2.5f, 15.5f, 6.5f), 1.5f, 1.5f, fill)
                line(c, 8.5f, 11f, 15.5f, 11f)
                line(c, 8.5f, 15f, 13f, 15f)
            }
            Ic.DOWNLOAD -> {
                line(c, 12f, 3.5f, 12f, 15f)
                p.reset(); p.moveTo(7f, 10.5f); p.lineTo(12f, 15.5f); p.lineTo(17f, 10.5f)
                c.drawPath(p, stroke)
                p.reset(); p.moveTo(4.5f, 15f); p.lineTo(4.5f, 19.5f); p.lineTo(19.5f, 19.5f); p.lineTo(19.5f, 15f)
                c.drawPath(p, stroke)
            }
            Ic.RGB -> {
                val colors = intArrayOf(
                    0xFFFF3B30.toInt(), 0xFFFFCC00.toInt(), 0xFF34C759.toInt(),
                    0xFF00C7FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFF3B30.toInt()
                )
                stroke.shader = SweepGradient(12f, 12f, colors, null)
                stroke.strokeWidth = 3.4f
                c.drawCircle(12f, 12f, 8f, stroke)
                stroke.shader = null
                stroke.color = iconColor
                stroke.strokeWidth = 2f
                c.drawCircle(12f, 12f, 2.2f, fill)
            }
            Ic.THEME -> {
                c.drawCircle(12f, 12f, 9f, stroke)
                c.drawArc(RectF(3f, 3f, 21f, 21f), 90f, 180f, true, fill)
            }
            Ic.WALL -> {
                c.drawRoundRect(RectF(3f, 4.5f, 21f, 19.5f), 3f, 3f, stroke)
                p.reset(); p.moveTo(3.5f, 17f); p.lineTo(9f, 11f); p.lineTo(13f, 15f); p.lineTo(16f, 12.5f); p.lineTo(20.5f, 17f)
                c.drawPath(p, stroke)
                c.drawCircle(16.5f, 9f, 1.5f, fill)
            }
            Ic.BOLT -> {
                p.reset()
                p.moveTo(13.5f, 2.5f); p.lineTo(5f, 13.5f); p.lineTo(11f, 13.5f); p.lineTo(10f, 21.5f)
                p.lineTo(19f, 10f); p.lineTo(13f, 10f); p.close()
                c.drawPath(p, fill)
            }
            Ic.GEAR -> {
                c.drawCircle(12f, 12f, 3.3f, stroke)
                c.drawCircle(12f, 12f, 7f, stroke)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val ca = cos(a).toFloat()
                    val sa = sin(a).toFloat()
                    line(c, 12f + ca * 7.6f, 12f + sa * 7.6f, 12f + ca * 10f, 12f + sa * 10f)
                }
            }
            Ic.BOOK -> {
                c.drawRoundRect(RectF(5f, 3f, 19f, 21f), 2.2f, 2.2f, stroke)
                line(c, 9f, 8f, 15f, 8f)
                line(c, 9f, 12f, 15f, 12f)
                line(c, 9f, 16f, 12.5f, 16f)
            }
            Ic.HELP -> {
                c.drawCircle(12f, 12f, 9.5f, stroke)
                text.color = iconColor
                text.textSize = 15f
                c.drawText("?", 12f, 17.4f, text)
            }
            Ic.INFO -> {
                c.drawCircle(12f, 12f, 9.5f, stroke)
                c.drawCircle(12f, 7.8f, 1.2f, fill)
                line(c, 12f, 11f, 12f, 17f)
            }
            Ic.NEWS -> {
                c.drawRoundRect(RectF(3.5f, 4.5f, 20.5f, 19.5f), 2.5f, 2.5f, stroke)
                c.drawRect(RectF(6.5f, 7.5f, 11.5f, 12f), fill)
                line(c, 14f, 8f, 17.5f, 8f)
                line(c, 14f, 11.5f, 17.5f, 11.5f)
                line(c, 6.5f, 15.5f, 17.5f, 15.5f)
            }
            Ic.CHAT -> {
                p.reset()
                p.addRoundRect(RectF(3f, 4f, 21f, 16.5f), 4f, 4f, Path.Direction.CW)
                p.moveTo(8f, 16.5f); p.lineTo(7f, 21f); p.lineTo(12.5f, 16.5f)
                c.drawPath(p, stroke)
                c.drawCircle(8.2f, 10.2f, 1.2f, fill)
                c.drawCircle(12f, 10.2f, 1.2f, fill)
                c.drawCircle(15.8f, 10.2f, 1.2f, fill)
            }
            Ic.HD -> {
                c.drawRoundRect(RectF(2.5f, 5f, 21.5f, 19f), 3.5f, 3.5f, stroke)
                text.color = iconColor
                text.textSize = 9.5f
                c.drawText("HD", 12f, 15.2f, text)
            }
            Ic.GLOBE -> {
                c.drawCircle(12f, 12f, 9.5f, stroke)
                c.drawOval(RectF(7.6f, 2.5f, 16.4f, 21.5f), stroke)
                line(c, 2.5f, 12f, 21.5f, 12f)
                line(c, 4.4f, 7.2f, 19.6f, 7.2f)
                line(c, 4.4f, 16.8f, 19.6f, 16.8f)
            }
            Ic.CHEVRON -> {
                p.reset(); p.moveTo(6.5f, 9.5f); p.lineTo(12f, 15f); p.lineTo(17.5f, 9.5f)
                stroke.strokeWidth = 2.6f
                c.drawPath(p, stroke)
            }
            Ic.PIN -> {
                c.save()
                c.rotate(35f, 12f, 12f)
                val paint = if (filled) fill else stroke
                c.drawRoundRect(RectF(8.5f, 2.5f, 15.5f, 12f), 2f, 2f, paint)
                line(c, 6.5f, 12f, 17.5f, 12f)
                line(c, 12f, 12f, 12f, 21f)
                c.restore()
            }
            Ic.TRASH -> {
                line(c, 4.5f, 6.5f, 19.5f, 6.5f)
                p.reset(); p.moveTo(9f, 6.5f); p.lineTo(9f, 3.8f); p.lineTo(15f, 3.8f); p.lineTo(15f, 6.5f)
                c.drawPath(p, stroke)
                p.reset(); p.moveTo(6.5f, 6.5f); p.lineTo(7.5f, 20f); p.lineTo(16.5f, 20f); p.lineTo(17.5f, 6.5f)
                c.drawPath(p, stroke)
                line(c, 10.2f, 10.5f, 10.2f, 16.5f)
                line(c, 13.8f, 10.5f, 13.8f, 16.5f)
            }
        }
    }

    /** Four-pointed sparkle. */
    private fun star(c: Canvas, cx: Float, cy: Float, r: Float, solid: Boolean) {
        val k = r * 0.22f
        p.reset()
        p.moveTo(cx, cy - r)
        p.quadTo(cx + k, cy - k, cx + r, cy)
        p.quadTo(cx + k, cy + k, cx, cy + r)
        p.quadTo(cx - k, cy + k, cx - r, cy)
        p.quadTo(cx - k, cy - k, cx, cy - r)
        p.close()
        c.drawPath(p, if (solid) fill else stroke)
    }
}
