package lk.example.sinhalakeyboard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

/** Checks the news feeds in the background and shows a notification for new headlines. */
class NewsJobService : JobService() {

    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try {
                runCheck(applicationContext)
            } catch (e: Exception) {
                // try again next time
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true

    companion object {
        private const val JOB_ID = 4201
        private const val CHANNEL = "sinha_news_v2"
        private val EVERY_MIN = longArrayOf(15, 30, 60, 180)

        /** Starts or stops the background check to match the settings. */
        fun apply(ctx: Context) {
            val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            val p = Prefs.of(ctx)
            if (!p.getBoolean(Prefs.NEWS_ALERTS, false)) {
                js.cancel(JOB_ID)
                return
            }
            val idx = p.getInt(Prefs.NEWS_EVERY, 2).coerceIn(0, EVERY_MIN.size - 1)
            val job = JobInfo.Builder(JOB_ID, ComponentName(ctx, NewsJobService::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(EVERY_MIN[idx] * 60_000L)
                .setPersisted(true)
                .build()
            js.schedule(job)
        }

        private fun runCheck(ctx: Context) {
            val p = Prefs.of(ctx)
            val items = News.fetch(ctx)
            if (items.isEmpty()) return
            val seen = LinkedHashSet<String>()
            val stored = p.getString(Prefs.NEWS_SEEN, "") ?: ""
            if (stored.isNotEmpty()) seen.addAll(stored.split("\n"))
            val first = seen.isEmpty()
            val fresh = items.filter { it.link !in seen }
            // the first run only remembers what is already there
            if (!first) notifyItems(ctx, fresh.take(3))
            for (i in fresh) seen.add(i.link)
            val keep = seen.toList().takeLast(400)
            p.edit().putString(Prefs.NEWS_SEEN, keep.joinToString("\n")).apply()
        }

        /** Shows one sample alert so the person can see how it looks. */
        fun sendTest(ctx: Context) {
            notifyItems(ctx, listOf(NewsItem("This is how a new headline will look. Tap to open.", "https://www.adaderana.lk", "Test", System.currentTimeMillis())))
        }

        private fun notifyItems(ctx: Context, items: List<NewsItem>) {
            if (items.isEmpty()) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "සිංහ news alert", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "New Sri Lankan headlines"
                    enableVibration(true)
                    enableLights(true)
                })
            }
            for (item in items) {
                val open = PendingIntent.getActivity(
                    ctx, item.link.hashCode(),
                    Intent(Intent.ACTION_VIEW, Uri.parse(item.link)),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CHANNEL)
                else Notification.Builder(ctx)
                b.setSmallIcon(R.drawable.ic_stat_lion)
                    .setContentTitle("සිංහ news alert")
                    .setSubText(item.source)
                    .setContentText(item.title)
                    .setColor(0xFFFF9A14.toInt())
                    .setWhen(if (item.time > 0L) item.time else System.currentTimeMillis())
                    .setShowWhen(true)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setStyle(Notification.BigTextStyle().bigText(item.title))
                    .setContentIntent(open)
                    .setAutoCancel(true)
                nm.notify(item.link.hashCode(), b.build())
            }
        }
    }
}
